import assert from 'node:assert/strict';
import {
  CRESTS,
  createThreatSchedule,
  finalScore,
  isActionLocked,
  makeFarm,
  makeRoom,
  actionById,
  projectPlotYield,
  rankFarms,
  resolveSeason,
  startNextSeason,
} from '../app/game/engine.ts';

const submission = (action, gateCorrect = true) => ({ action, gateCorrect, sabotageTarget: null, sabotageCorrect: null, emote: null });

function singleSeason(action, threat, setup = () => {}) {
  const farm = makeFarm(0, 'Test Farm', CRESTS[0]);
  setup(farm);
  const room = makeRoom('TEST', farm, 4);
  room.phase = 'choice';
  room.season = 1;
  room.threatSchedule = [threat, 'CALM', 'POOR_SOIL', 'LOCUSTS', 'WEEDS'];
  room.submissions['0'] = submission(action);
  return resolveSeason(room);
}

const start = makeFarm(0, 'Start', CRESTS[0]);
assert.equal(start.plots, 4, 'Every farm starts with four plots');
assert.equal('money' in start, false, 'Money has been removed from farm state');

const schedule = createThreatSchedule('ABCD');
assert.deepEqual(createThreatSchedule('ABCD'), schedule, 'A room sees one stable shared random schedule');
assert.ok(['CALM', 'POOR_SOIL', 'LOCUSTS', 'WEEDS'].every((threat) => schedule.includes(threat)), 'Every game includes all four core events');

const locustUntreated = singleSeason('DO_NOTHING', 'LOCUSTS');
const locustSprayed = singleSeason('PESTICIDE', 'LOCUSTS');
assert.equal(locustUntreated.farms[0].history[0].perPlotYield, 0, 'Locusts can destroy an unprotected baseline plot');
assert.equal(locustSprayed.farms[0].history[0].perPlotYield, 2, 'Pesticide is useful when locusts are actually present');
assert.equal(locustSprayed.farms[0].pollinatorDamage, 1, 'Pesticide creates a next-season non-target insect penalty');

const weedUntreated = singleSeason('DO_NOTHING', 'WEEDS');
const weedControlled = singleSeason('HERBICIDE', 'WEEDS');
assert.equal(weedControlled.farms[0].history[0].harvest - weedUntreated.farms[0].history[0].harvest, 4, 'Herbicide prevents one lost crop on each of four plots');

const poorUntreated = singleSeason('DO_NOTHING', 'POOR_SOIL');
const poorFed = singleSeason('FERTILISER', 'POOR_SOIL');
assert.equal(poorFed.farms[0].history[0].harvest, 16, 'Fertiliser both replaces missing nutrients and adds a two-crop plot boost');
assert.equal(poorUntreated.farms[0].history[0].harvest, 4, 'Poor soil visibly punishes an unmatched response');

const bio = singleSeason('BIO_CONTROL', 'LOCUSTS');
assert.equal(bio.farms[0].history[0].perPlotYield, 1, 'Biological control uses one crop per plot while habitat establishes');
assert.equal(bio.farms[0].hasBioControl, true, 'Biological control remains active for later locust events');
assert.equal(bio.farms[0].riverContributed, 0, 'Biological control avoids chemical runoff');

let recoveryRoom = makeRoom('REST', makeFarm(0, 'Recovery', CRESTS[0]), 4);
recoveryRoom.phase = 'choice';
recoveryRoom.season = 1;
recoveryRoom.threatSchedule = ['CALM', 'CALM', 'POOR_SOIL', 'LOCUSTS', 'WEEDS'];
recoveryRoom.farms[0].soilContamination = 2;
recoveryRoom.submissions['0'] = submission('DO_NOTHING');
recoveryRoom = resolveSeason(recoveryRoom);
assert.equal(recoveryRoom.farms[0].soilContamination, 1, 'Doing nothing removes one soil residue');
assert.equal(recoveryRoom.farms[0].restBonus, 1, 'Doing nothing prepares a next-season plot bonus');
recoveryRoom = startNextSeason(recoveryRoom, 0);
assert.equal(projectPlotYield(recoveryRoom.farms[0], 'DO_NOTHING', 'CALM').perPlot, 3, 'Rested soil produces one extra crop per plot next season');

const improvedOnPoorSoil = singleSeason('IMPROVED_PLANT', 'POOR_SOIL');
assert.equal(improvedOnPoorSoil.farms[0].history[0].perPlotYield, 1, 'High-yield plants do not bypass their greater mineral demand');

const locustBurn = singleSeason('SLASH_BURN', 'LOCUSTS');
assert.equal(locustBurn.farms[0].history[0].threatReason, 'locust swarm', 'Burning does not magically stop locusts');
assert.equal(isActionLocked(locustBurn.farms[0], actionById('SLASH_BURN')), 'Already used', 'Clearing cannot be repeated');

const finalBurnFarm = makeFarm(0, 'Final Burn', CRESTS[0]);
const finalBurnRoom = makeRoom('FIVE', finalBurnFarm, 4);
finalBurnRoom.phase = 'choice';
finalBurnRoom.season = 5;
finalBurnRoom.threatSchedule = ['CALM', 'POOR_SOIL', 'LOCUSTS', 'WEEDS', 'CALM'];
finalBurnRoom.submissions['0'] = submission('SLASH_BURN');
const finalBurn = resolveSeason(finalBurnRoom);
assert.equal(finalBurn.farms[0].plots, 4, 'Final-season clearing settles its promised future land loss');
assert.ok(finalBurn.events.some((event) => event.kind === 'erosion'), 'Final-season erosion is still revealed');

const livestockFarm = makeFarm(0, 'Livestock Farm', CRESTS[0]);
livestockFarm.livestockYield = 3;
let bloom = makeRoom('BLOM', livestockFarm, 4);
bloom.phase = 'choice';
bloom.season = 1;
bloom.threatSchedule = ['CALM', 'CALM', 'POOR_SOIL', 'LOCUSTS', 'WEEDS'];
bloom.river = 7;
bloom.submissions['0'] = submission('FERTILISER');
bloom = resolveSeason(bloom);
assert.equal(bloom.farms[0].history[0].sharedEventLoss, 6, 'A new bloom removes three crops and all livestock food');
bloom = startNextSeason(bloom, 0);
bloom.submissions['0'] = submission('DO_NOTHING');
bloom = resolveSeason(bloom);
assert.equal(bloom.farms[0].history[1].sharedEventLoss, 3, 'An ongoing bloom keeps livestock loss visible');

const highYieldDirty = makeFarm(0, 'Dirty Yield', CRESTS[0]);
highYieldDirty.totalCrops = 100;
highYieldDirty.riverContributed = 20;
const balanced = makeFarm(1, 'Balanced', CRESTS[1]);
balanced.totalCrops = 90;
assert.ok(finalScore(balanced) > finalScore(highYieldDirty), 'Environmental damage can erase a raw-yield lead');
assert.equal(rankFarms([highYieldDirty, balanced])[0].slot, balanced.slot, 'Ranking follows the stated Best Overall rule');

function runFourFarmStrategy(label, actions) {
  const room = makeRoom(label.slice(0, 4).toUpperCase(), makeFarm(0, `${label} 1`, CRESTS[0]), 4);
  room.farms = Array.from({ length: 4 }, (_, slot) => makeFarm(slot, `${label} ${slot + 1}`, CRESTS[slot]));
  room.threatSchedule = ['CALM', 'POOR_SOIL', 'LOCUSTS', 'WEEDS', 'LOCUSTS'];
  room.phase = 'briefing';
  let state = startNextSeason(room, 0);
  for (const action of actions) {
    for (const farm of state.farms) state.submissions[String(farm.slot)] = submission(action);
    state = resolveSeason(state);
    if (state.season < 5) state = startNextSeason(state, 0);
  }
  return state;
}

const extract = (state) => ({
  score: finalScore(state.farms[0]),
  food: state.farms[0].totalCrops,
  river: state.farms[0].riverContributed,
  haze: state.farms[0].hazeContributed,
  soil: state.farms[0].soilContamination,
  plots: state.farms[0].plots,
});

const sustainable = runFourFarmStrategy('Sustainable', ['DO_NOTHING', 'FERTILISER', 'BIO_CONTROL', 'HORMONE_WEED', 'IMPROVED_PLANT']);
const extractive = runFourFarmStrategy('Extractive', ['SLASH_BURN', 'FERTILISER', 'PESTICIDE', 'HERBICIDE', 'HORMONE_RIPEN']);
assert.ok(finalScore(sustainable.farms[0]) > finalScore(extractive.farms[0]), 'A matched lower-impact strategy beats repeated extraction overall');

console.log(JSON.stringify({ checks: 'all passed', schedule, sustainable: extract(sustainable), extractive: extract(extractive) }, null, 2));
