import { env } from 'cloudflare:workers';
import { NextRequest, NextResponse } from 'next/server';
import { CRESTS, makeFarm, makeRoom, resolveSeason, startNextSeason, type Crest, type RoomState, type Submission } from '../../game/engine';

const ROOM_CODE_ALPHABET = 'BCDFGHJKLMNPQRSTVWXYZ';

async function ensureSchema() {
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS rooms (
    code TEXT PRIMARY KEY,
    state TEXT NOT NULL,
    version INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL
  )`).run();
}

function codeFromBytes(bytes: Uint8Array) {
  return Array.from(bytes, (n) => ROOM_CODE_ALPHABET[n % ROOM_CODE_ALPHABET.length]).join('');
}

async function createCode() {
  for (let i = 0; i < 12; i += 1) {
    const candidate = codeFromBytes(crypto.getRandomValues(new Uint8Array(4)));
    const exists = await env.DB.prepare('SELECT code FROM rooms WHERE code = ?').bind(candidate).first();
    if (!exists) return candidate;
  }
  throw new Error('Could not create a room code');
}

function publicState(state: RoomState): RoomState {
  const clone = structuredClone(state);
  clone.farms.forEach((farm) => { delete farm.token; });
  return clone;
}

async function readRoom(code: string) {
  const row = await env.DB.prepare('SELECT state, version FROM rooms WHERE code = ?').bind(code).first<{ state: string; version: number }>();
  if (!row) return null;
  return { state: JSON.parse(row.state) as RoomState, version: row.version };
}

function advanceIfNeeded(state: RoomState, now: number) {
  if (state.phase === 'setup' && state.deadline && now >= state.deadline) {
    state.farms.forEach((farm) => {
      if (!farm.setupDone) { farm.setupDone = true; farm.setupCorrect = false; farm.plots = 4; }
    });
    state.season = 0; state.phase = 'briefing'; state.deadline = null;
    state.farms.forEach((farm) => { farm.ready = false; });
    state.revision += 1;
    return state;
  }
  if (state.phase !== 'choice') return state;
  const allIn = state.farms.length === state.pairCount && state.farms.every((farm) => state.submissions[String(farm.slot)]);
  if (!allIn && (!state.deadline || now < state.deadline)) return state;
  for (const farm of state.farms) {
    state.submissions[String(farm.slot)] ??= { action: 'DO_NOTHING', gateCorrect: false, sabotageTarget: null, sabotageCorrect: null, emote: null };
  }
  return resolveSeason(state);
}

async function updateRoom(code: string, change: (state: RoomState) => RoomState | Promise<RoomState>) {
  for (let attempt = 0; attempt < 8; attempt += 1) {
    const current = await readRoom(code);
    if (!current) return null;
    const changed = await change(structuredClone(current.state));
    const result = await env.DB.prepare('UPDATE rooms SET state = ?, version = version + 1 WHERE code = ? AND version = ?')
      .bind(JSON.stringify(changed), code, current.version).run();
    if (result.meta.changes === 1) return changed;
  }
  throw new Error('Room was busy. Please try again.');
}

function cleanName(value: unknown) {
  return String(value ?? '').trim().replace(/\s+/g, ' ').slice(0, 28);
}

function validateSession(state: RoomState, slot: number, token: string) {
  const farm = state.farms.find((item) => item.slot === slot);
  return farm && farm.token === token ? farm : null;
}

export async function GET(request: NextRequest) {
  await ensureSchema();
  const code = request.nextUrl.searchParams.get('code')?.trim().toUpperCase() ?? '';
  if (!/^[A-Z]{4}$/.test(code)) return NextResponse.json({ error: 'Enter a four-letter room code.' }, { status: 400 });
  const current = await readRoom(code);
  if (!current) return NextResponse.json({ error: 'Room not found.' }, { status: 404 });
  const advanced = advanceIfNeeded(structuredClone(current.state), Date.now());
  let state = current.state;
  if (JSON.stringify(advanced) !== JSON.stringify(current.state)) state = (await updateRoom(code, (fresh) => advanceIfNeeded(fresh, Date.now()))) ?? advanced;
  return NextResponse.json({ state: publicState(state) });
}

export async function POST(request: NextRequest) {
  await ensureSchema();
  const body = await request.json() as Record<string, unknown>;
  const type = String(body.type ?? '');

  if (type === 'create') {
    const name = cleanName(body.name);
    const pairCount = Math.max(2, Math.min(4, Number(body.pairCount) || 4));
    const crest = CRESTS.includes(body.crest as Crest) ? body.crest as Crest : CRESTS[0];
    if (!name) return NextResponse.json({ error: 'Enter your pair names.' }, { status: 400 });
    const code = await createCode();
    const token = crypto.randomUUID();
    const state = makeRoom(code, makeFarm(0, name, crest, token), pairCount);
    await env.DB.prepare('INSERT INTO rooms (code, state, version, created_at) VALUES (?, ?, 0, ?)')
      .bind(code, JSON.stringify(state), Date.now()).run();
    return NextResponse.json({ state: publicState(state), slot: 0, token });
  }

  const code = String(body.code ?? '').trim().toUpperCase();
  if (!/^[A-Z]{4}$/.test(code)) return NextResponse.json({ error: 'Enter a valid room code.' }, { status: 400 });

  if (type === 'join') {
    const name = cleanName(body.name);
    if (!name) return NextResponse.json({ error: 'Enter your pair names.' }, { status: 400 });
    const token = crypto.randomUUID();
    let claimedSlot = -1;
    const state = await updateRoom(code, (room) => {
      if (room.farms.length >= room.pairCount || room.phase !== 'lobby') throw new Error('This room is already full.');
      const used = new Set(room.farms.map((farm) => farm.slot));
      claimedSlot = Array.from({ length: room.pairCount }, (_, index) => index).find((slot) => !used.has(slot)) ?? -1;
      const usedCrests = new Set(room.farms.map((farm) => farm.crest));
      const requested = CRESTS.includes(body.crest as Crest) ? body.crest as Crest : CRESTS[claimedSlot];
      const crest = usedCrests.has(requested) ? CRESTS.find((item) => !usedCrests.has(item))! : requested;
      room.farms.push(makeFarm(claimedSlot, name, crest, token));
      room.farms.sort((a, b) => a.slot - b.slot);
      if (room.farms.length === room.pairCount) { room.phase = 'setup'; room.deadline = Date.now() + 90_000; }
      room.revision += 1;
      return room;
    }).catch((error: Error) => ({ error: error.message }));
    if (!state || 'error' in state) return NextResponse.json({ error: state?.error ?? 'Room not found.' }, { status: 409 });
    return NextResponse.json({ state: publicState(state), slot: claimedSlot, token });
  }

  const slot = Number(body.slot);
  const token = String(body.token ?? '');
  try {
    const state = await updateRoom(code, (room) => {
      const farm = validateSession(room, slot, token);
      if (!farm) throw new Error('This device no longer owns that farm slot.');

      if (type === 'setup') {
        if (room.phase !== 'setup') throw new Error('Setup is not open.');
        if (farm.setupDone) throw new Error('This farm already completed setup.');
        const choices = Array.isArray(body.choices) ? body.choices.map(String) : [];
        const correct = choices.length === 5 && ['air', 'light', 'water', 'nutrients', 'ph'].every((need) => choices.includes(need));
        farm.setupCorrect = correct; farm.plots = 4;
        if (correct) farm.setupDone = true;
        if (room.farms.length === room.pairCount && room.farms.every((item) => item.setupDone)) {
          room.season = 0; room.phase = 'briefing'; room.deadline = null;
          room.farms.forEach((item) => { item.ready = false; });
          room.revision += 1;
          return room;
        }
      } else if (type === 'briefing_ready') {
        if (room.phase !== 'briefing') throw new Error('The rules briefing is not open.');
        farm.ready = true;
        if (room.farms.every((item) => item.ready)) return startNextSeason(room);
      } else if (type === 'submit') {
        if (room.phase !== 'choice') throw new Error('This season is not accepting choices.');
        if (!room.submissions[String(slot)]) room.submissions[String(slot)] = body.submission as Submission;
        return advanceIfNeeded(room, Date.now());
      } else if (type === 'ready') {
        if (room.phase !== 'results') throw new Error('The room is not on the results screen.');
        farm.ready = true;
        if (room.farms.every((item) => item.ready)) return startNextSeason(room);
      } else throw new Error('Unknown room action.');
      room.revision += 1;
      return room;
    });
    if (!state) return NextResponse.json({ error: 'Room not found.' }, { status: 404 });
    return NextResponse.json({ state: publicState(state) });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Room action failed.' }, { status: 409 });
  }
}
