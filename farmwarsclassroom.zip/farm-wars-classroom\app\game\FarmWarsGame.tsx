'use client';

import { useEffect, useRef, useState } from 'react';
import {
  ACTIONS, CHOICE_TIME_MS, CORRECT_NEEDS, CREST_ART, CRESTS, DEMAND, GAME_RULES, NEEDS,
  actionById, finalScore, isActionLocked, makeFarm, makeRoom, rankFarms, resolveSeason,
  missedDemandCount, projectPlotYield, scienceStars, seededQuestion, seededSabotageQuestion, startNextSeason, threatFor,
  type ActionId, type Crest, type Question, type RoomState, type Submission, type ThreatDefinition,
} from './engine';

type Mode = 'menu' | 'room-form' | 'local-roster' | 'room' | 'local';
type GateStage = 'sabotage' | 'card';
type ApiReply = { state?: RoomState; slot?: number; token?: string; error?: string };
type GateResult = { correct: boolean; explanation: string; after: 'card' | 'retry' | 'submit'; corrected?: boolean; submission?: Submission };

const EMPTY_SUB: Submission = { action: 'DO_NOTHING', gateCorrect: false, sabotageTarget: null, sabotageCorrect: null, emote: null };
const LEARNING_NOTES: Record<ActionId, string> = {
  FERTILISER: 'Fertilisers replace mineral nutrients in soil, but rain can wash excess nutrients into rivers and cause algal blooms.',
  PESTICIDE: 'Pesticides kill pests quickly, but residues can enter water and food chains; non-target pollinators may also be harmed.',
  HERBICIDE: 'Herbicides remove weeds that compete with crops for light, water and mineral nutrients.',
  SLASH_BURN: 'Burning clears land and ash briefly adds nutrients, but bare soil later erodes and smoke creates haze.',
  EMERGENCY_CLEARING: 'Emergency clearing gains land fast, but causes even more haze and delayed erosion.',
  BIO_CONTROL: 'Biological control uses natural predators. Habitat takes some field space while it establishes, then protects future crops.',
  IMPROVED_PLANT: 'Improved varieties can yield more, but higher growth creates a greater demand for mineral nutrients.',
  IMPROVED_ANIMAL: 'Improved animals produce more food, while manure can add nutrients to runoff and intensify an algal bloom.',
  INTENSIVE: 'Intensive farming raises output by crowding animals, increasing manure runoff and creating an animal-welfare trade-off.',
  HORMONE_WEED: 'Some auxin-like plant hormones act as selective weedkillers; this model gives the lower-dose choice one soil-residue point.',
  HORMONE_RIPEN: 'Plant hormones regulate growth and can control when fruits ripen.',
  DO_NOTHING: 'A low-input season leaves the current threat untreated, but residues can break down and rested soil improves next season’s yield.',
};
const ACTION_GROUPS = [
  { id: 'quick', label: 'Act this season', hint: 'Fast answers to today’s threat', actions: ['FERTILISER', 'PESTICIDE', 'HERBICIDE', 'HORMONE_WEED', 'DO_NOTHING'] as ActionId[] },
  { id: 'upgrade', label: 'Build for later', hint: 'Permanent farm improvements', actions: ['BIO_CONTROL', 'IMPROVED_PLANT', 'IMPROVED_ANIMAL', 'INTENSIVE'] as ActionId[] },
  { id: 'bold', label: 'Bold moves', hint: 'Big gains, special limits or heavy consequences', actions: ['SLASH_BURN', 'EMERGENCY_CLEARING', 'HORMONE_RIPEN'] as ActionId[] },
] as const;
function missionFor(threat: ThreatDefinition) {
  if (threat.id === 'LOCUSTS') return 'Compare immediate chemical pest control with slower, lasting biological control.';
  if (threat.id === 'WEEDS') return 'Explain competition and compare the residue costs of two selective weed controls.';
  if (threat.id === 'POOR_SOIL') return 'Link mineral nutrients to plant growth, then weigh extra yield against fertiliser runoff.';
  return 'Decide whether growth is worth a new impact when the farm has no urgent biological threat.';
}
const EVENT_CHAINS = {
  algal: [
    ['6.1', 'Rain falls on a fertilised field'], ['6.2', 'Runoff enters the river'],
    ['6.3', 'Algae multiply rapidly'], ['6.4', 'The algae layer blocks sunlight'],
    ['6.5', 'Plants and algae die; decomposers break them down'], ['6.6', 'Bacterial respiration uses oxygen, so fish suffocate'],
  ],
  soil: [
    ['6.7', 'Chemicals contaminate the soil'], ['6.8', 'A hen eats an earthworm'],
    ['6.9', 'Residues can build up through the food chain'], ['6.10', 'Concentrated harmful substances enter a human'],
  ],
  haze: [['6.14', 'The village disappears under thick haze'], ['6.15', 'People cough and need masks']],
  erosion: [['6.16', 'Tree roots hold the topsoil'], ['6.17', 'Cut trees leave topsoil bare'], ['6.18', 'Rain washes the topsoil away']],
} as const;

function crestFor(slot: number) { return CREST_ART[slot] ?? CREST_ART[0]; }
function actionArt(id: ActionId) { return `/assets/cards/${actionById(id).art}.png`; }
function formatTime(ms: number) { const s = Math.max(0, Math.ceil(ms / 1000)); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`; }

export default function FarmWarsGame() {
  const [mode, setMode] = useState<Mode>('menu');
  const [room, setRoom] = useState<RoomState | null>(null);
  const [slot, setSlot] = useState(0);
  const [token, setToken] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [pairName, setPairName] = useState('');
  const [crest, setCrest] = useState<Crest>('wheat');
  const [roomCode, setRoomCode] = useState('');
  const [pairCount, setPairCount] = useState(4);
  const [localNames, setLocalNames] = useState(['Pair 1', 'Pair 2', 'Pair 3', 'Pair 4']);
  const [setupSlot, setSetupSlot] = useState(0);
  const [needs, setNeeds] = useState<string[]>([]);
  const [setupFeedback, setSetupFeedback] = useState('');
  const [activeSlot, setActiveSlot] = useState(0);
  const [passReady, setPassReady] = useState(false);
  const [selectedAction, setSelectedAction] = useState<ActionId | null>(null);
  const [gate, setGate] = useState<{ stage: GateStage; question: Question } | null>(null);
  const [gateResult, setGateResult] = useState<GateResult | null>(null);
  const [gateHadMiss, setGateHadMiss] = useState(false);
  const [sabotageTarget, setSabotageTarget] = useState<number | null>(null);
  const [sabotageCorrect, setSabotageCorrect] = useState<boolean | null>(null);
  const [emote, setEmote] = useState<number | null>(null);
  const [now, setNow] = useState(Date.now());
  const [finaleProgress, setFinaleProgress] = useState({ key: '', ready: false });
  const autoSent = useRef('');

  const ownSlot = mode === 'local' ? activeSlot : slot;
  const farm = room?.farms.find((item) => item.slot === ownSlot) ?? null;
  const ranks = room ? rankFarms(room.farms) : [];
  const finaleKey = room?.phase === 'final' ? `${room.code}-${room.season}-final` : '';
  const finaleReady = finaleProgress.key === finaleKey && finaleProgress.ready;

  useEffect(() => {
    const timer = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    if (mode !== 'room' || !room?.code) return;
    const poll = window.setInterval(async () => {
      try {
        const response = await fetch(`/api/rooms?code=${room.code}`, { cache: 'no-store' });
        const data = await response.json() as ApiReply;
        if (data.state) setRoom(data.state);
      } catch { /* The next poll will retry. */ }
    }, 2000);
    return () => window.clearInterval(poll);
  }, [mode, room?.code]);

  useEffect(() => {
    if (!room || room.phase !== 'choice' || !room.deadline || now < room.deadline || room.submissions[String(ownSlot)]) return;
    const key = `${room.code}-${room.season}-${ownSlot}`;
    if (autoSent.current === key) return;
    autoSent.current = key;
    if (mode === 'room') void sendRoom('submit', { submission: EMPTY_SUB });
    else submitLocal(EMPTY_SUB);
  }, [now, room?.deadline, room?.phase, room?.season, ownSlot, mode]);

  async function api(body: Record<string, unknown>) {
    setBusy(true); setError('');
    try {
      const response = await fetch('/api/rooms', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      const data = await response.json() as ApiReply;
      if (!response.ok || data.error) throw new Error(data.error ?? 'The room could not be updated.');
      return data;
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'The room could not be updated.');
      return null;
    } finally { setBusy(false); }
  }

  async function createRoom() {
    const data = await api({ type: 'create', name: pairName, crest, pairCount });
    if (!data?.state || data.slot === undefined || !data.token) return;
    setRoom(data.state); setSlot(data.slot); setToken(data.token); setMode('room');
    localStorage.setItem(`farm-wars:${data.state.code}`, JSON.stringify({ slot: data.slot, token: data.token }));
  }

  async function joinRoom() {
    const returningCode = roomCode.toUpperCase();
    const saved = localStorage.getItem(`farm-wars:${returningCode}`);
    if (saved) {
      try {
        const session = JSON.parse(saved) as { slot: number; token: string };
        const response = await fetch(`/api/rooms?code=${returningCode}`, { cache: 'no-store' });
        const restored = await response.json() as ApiReply;
        if (response.ok && restored.state?.farms.some((item) => item.slot === session.slot)) {
          setRoom(restored.state); setSlot(session.slot); setToken(session.token); setMode('room'); setError('');
          return;
        }
      } catch { localStorage.removeItem(`farm-wars:${returningCode}`); }
    }
    const data = await api({ type: 'join', code: roomCode.toUpperCase(), name: pairName, crest });
    if (!data?.state || data.slot === undefined || !data.token) return;
    setRoom(data.state); setSlot(data.slot); setToken(data.token); setMode('room');
    localStorage.setItem(`farm-wars:${data.state.code}`, JSON.stringify({ slot: data.slot, token: data.token }));
  }

  async function sendRoom(type: string, extra: Record<string, unknown> = {}) {
    if (!room) return;
    const data = await api({ type, code: room.code, slot, token, ...extra });
    if (data?.state) setRoom(data.state);
  }

  function startLocal() {
    const first = makeFarm(0, localNames[0] || 'Pair 1', CRESTS[0]);
    const local = makeRoom('LOCAL', first, 4);
    local.farms = localNames.map((name, index) => makeFarm(index, name.trim() || `Pair ${index + 1}`, CRESTS[index]));
    local.phase = 'setup';
    setRoom(local); setSetupSlot(0); setNeeds([]); setSetupFeedback(''); setMode('local');
  }

  function startDemo() {
    const demo = makeRoom('DEMO', makeFarm(0, 'Your Pair', CRESTS[0]), 4);
    demo.farms = ['Your Pair', 'River Rangers', 'Harvest Heroes', 'Oak Alliance'].map((name, index) => makeFarm(index, name, CRESTS[index]));
    const actions: ActionId[] = ['SLASH_BURN', 'BIO_CONTROL', 'IMPROVED_ANIMAL', 'FERTILISER'];
    demo.threatSchedule = ['CALM', 'POOR_SOIL', 'LOCUSTS', 'WEEDS', 'LOCUSTS'];
    demo.farms.forEach((item, index) => {
      item.setupDone = true; item.setupCorrect = true; item.plots = [6, 4, 4, 4][index]; item.totalCrops = [18, 15, 20, 16][index];
      item.plantBonus = index === 1 ? 1 : 0; item.livestockYield = index === 2 ? 3 : 0; item.hasBioControl = index === 1;
      item.riverContributed = index === 2 ? 1 : index === 3 ? 2 : 0; item.hazeContributed = index === 0 ? 3 : 0;
      if (actionById(actions[index]).once) item.usedActions.push(actions[index]);
      if (index === 1) item.usedActions.push('IMPROVED_PLANT');
      if (actions[index] === 'SLASH_BURN') { item.ashSeasonsLeft = 1; item.ashBonus = 1; item.erosionDueSeason = 4; item.erosionAmount = 2; }
      item.history.push({ season: 2, action: actions[index], attemptedAction: actions[index], gateCorrect: true, harvest: [14, 10, 15, 16][index], potentialHarvest: [14, 10, 15, 16][index], actionGain: [6, 2, 3, 8][index], plotHarvest: [14, 10, 12, 16][index], livestockHarvest: index === 2 ? 3 : 0, ripeningGain: 0, perPlotYield: [3, 2, 3, 4][index], plotFormula: ['2 base', '= modelled plot yield'], threatLoss: 0, threatReason: null, biodiversityLoss: 0, establishmentLoss: 0, soilLoss: 0, sharedEventLoss: 0, recoveryApplied: 0, met: index !== 1, river: index === 2 ? 1 : index === 3 ? 2 : 0, haze: index === 0 ? 3 : 0, soilEvent: false, burnedSeasonFive: false, emote: null, sabotageTarget: null, sabotageFailed: false, sabotagedBy: [], sabotageLoss: 0 });
    });
    demo.phase = 'choice'; demo.season = 3; demo.deadline = Date.now() + 3_600_000; demo.river = 3; demo.haze = 3; demo.riverCostsRevealed = true;
    setRoom(demo); setMode('local'); setActiveSlot(0); setPassReady(true); resetChoice();
  }

  function toggleNeed(id: string) {
    setNeeds((current) => current.includes(id) ? current.filter((item) => item !== id) : current.length < 5 ? [...current, id] : current);
  }

  async function submitSetup() {
    if (needs.length !== 5) { setSetupFeedback('Choose exactly five icons.'); return; }
    const correct = [...CORRECT_NEEDS].every((item) => needs.includes(item));
    if (!correct) {
      setSetupFeedback('Not yet: plants need air, light, water, nutrients and a suitable pH. Change your choices and try again—every farm still starts with 4 equal plots.');
      return;
    }
    if (mode === 'room') {
      setSetupFeedback('Correct — your farm starts equally with 4 plots.');
      await sendRoom('setup', { choices: needs }); setNeeds([]); return;
    }
    if (!room) return;
    const next = structuredClone(room);
    const current = next.farms[setupSlot];
    current.setupDone = true; current.setupCorrect = correct; current.plots = 4;
    setSetupFeedback('Correct — your farm starts equally with 4 plots.');
    window.setTimeout(() => {
      if (setupSlot < next.farms.length - 1) { setSetupSlot((value) => value + 1); setNeeds([]); setSetupFeedback(''); }
      else { const advanced = structuredClone(next); advanced.phase = 'briefing'; advanced.deadline = null; advanced.farms.forEach((item) => { item.ready = false; }); setRoom(advanced); setActiveSlot(0); setPassReady(false); setNeeds([]); setSetupFeedback(''); }
    }, 1200);
    setRoom(next);
  }

  function chooseAction(id: ActionId) {
    if (!room || !farm) return;
    const definition = actionById(id);
    if (isActionLocked(farm, definition) || room.submissions[String(ownSlot)]) return;
    setSelectedAction(id);
  }

  function beginGate() {
    if (!room || !farm || !selectedAction) return;
    setGateResult(null);
    setGateHadMiss(false);
    if (sabotageTarget !== null && farm.sabotageTokens > 0) {
      setGate({ stage: 'sabotage', question: seededSabotageQuestion(room.code, farm.slot, room.season) });
    } else setGate({ stage: 'card', question: seededQuestion(actionById(selectedAction), room.code, farm.slot, room.season) });
  }

  function answerGate(answer: string) {
    if (!gate || !room || !farm || !selectedAction || gateResult) return;
    const correct = answer === gate.question.answer;
    if (gate.stage === 'sabotage') {
      setSabotageCorrect(correct);
      setGateResult({
        correct,
        explanation: correct ? `${gate.question.answer}. The attempt is armed; its effect stays hidden until the class reveal.` : `${gate.question.answer}. The attempt backfires; the full result appears with every farm’s reveal.`,
        after: correct ? 'card' : 'submit',
        submission: correct ? undefined : { action: selectedAction, gateCorrect: false, sabotageTarget, sabotageCorrect: false, emote },
      });
      return;
    }
    if (!correct) {
      setGateHadMiss(true);
      setGateResult({ correct: false, explanation: `The correct answer is ${gate.question.answer}. Use that science to revise your prediction, then try again.`, after: 'retry' });
      return;
    }
    setGateResult({
      correct: true,
      explanation: `${gate.question.answer}. Your action is ready; its farm and environmental consequences stay hidden until every farm locks.`,
      corrected: gateHadMiss,
      after: 'submit',
      submission: { action: selectedAction, gateCorrect: !gateHadMiss, sabotageTarget, sabotageCorrect, emote },
    });
  }

  function continueGate() {
    if (!gateResult || !room || !farm || !selectedAction) return;
    if (gateResult.after === 'card') {
      setGate({ stage: 'card', question: seededQuestion(actionById(selectedAction), room.code, farm.slot, room.season) });
      setGateResult(null);
      setGateHadMiss(false);
      return;
    }
    if (gateResult.after === 'retry') {
      setGateResult(null);
      return;
    }
    if (gateResult.submission) finishSubmission(gateResult.submission);
  }

  function beginLocalTurn() {
    if (room) {
      const next = structuredClone(room);
      next.deadline = Date.now() + CHOICE_TIME_MS;
      setRoom(next);
    }
    setPassReady(true);
  }

  function resetChoice() {
    setSelectedAction(null); setGate(null); setGateResult(null); setGateHadMiss(false); setSabotageTarget(null); setSabotageCorrect(null); setEmote(null);
  }

  function finishSubmission(submission: Submission) {
    setGate(null);
    if (mode === 'room') void sendRoom('submit', { submission });
    else submitLocal(submission);
    resetChoice();
  }

  function submitLocal(submission: Submission) {
    if (!room) return;
    const next = structuredClone(room);
    next.submissions[String(activeSlot)] = submission;
    if (activeSlot < next.farms.length - 1) {
      setRoom(next); setActiveSlot((value) => value + 1); setPassReady(false);
    } else {
      setRoom(resolveSeason(next)); setActiveSlot(0); setPassReady(false);
    }
  }

  function continueSeason() {
    if (!room) return;
    if (mode === 'room') void sendRoom('ready');
    else { setRoom(startNextSeason(room)); setActiveSlot(0); setPassReady(false); resetChoice(); }
  }

  function finishBriefing() {
    if (!room) return;
    if (mode === 'room') void sendRoom('briefing_ready');
    else { setRoom(startNextSeason(room)); setActiveSlot(0); setPassReady(false); }
  }

  function restart() {
    setMode('menu'); setRoom(null); setError(''); setPairName(''); setRoomCode(''); resetChoice();
  }

  if (mode === 'menu') return <TitleScreen onRoom={() => setMode('room-form')} onLocal={() => setMode('local-roster')} onDemo={startDemo} />;

  if (mode === 'room-form') return (
    <Shell><section className="wood-panel form-panel">
      <button className="text-button" onClick={() => setMode('menu')}>← Back</button>
      <p className="eyebrow">Classroom room</p><h2>Claim your farm</h2>
      <label>Pair names<input value={pairName} onChange={(event) => setPairName(event.target.value)} placeholder="e.g. Ali & Siti" maxLength={28} /></label>
      <div><span className="field-label">Choose a crest</span><div className="crest-picker">{CRESTS.map((item, index) => <button key={item} className={crest === item ? 'selected' : ''} onClick={() => setCrest(item)}><img src={CREST_ART[index]} alt={`${item} crest`} /><span>{item}</span></button>)}</div></div>
      <div className="room-actions">
        <div><h3>First pair: create</h3><p>Make the shared server room, then put its four-letter code on the board.</p><label>Teams<select value={pairCount} onChange={(event) => setPairCount(Number(event.target.value))}><option value={4}>4 teams</option><option value={3}>3 teams</option><option value={2}>2 teams</option></select></label><button className="primary" disabled={busy} onClick={createRoom}>Create server room</button></div>
        <div className="join-block"><h3>Other pairs: join</h3><p>Open this site on your own device and enter the code. Everyone plays at the same time.</p><label>Room code<input className="code-input" value={roomCode} onChange={(event) => setRoomCode(event.target.value.toUpperCase().replace(/[^A-Z]/g, '').slice(0, 4))} placeholder="BKTR" /></label><button className="primary" disabled={busy} onClick={joinRoom}>Join on this device</button></div>
      </div>
      {error && <p className="error" role="alert">{error}</p>}
    </section></Shell>
  );

  if (mode === 'local-roster') return (
    <Shell><section className="wood-panel form-panel">
      <button className="text-button" onClick={() => setMode('menu')}>← Back</button>
      <p className="eyebrow">One-device fallback</p><h2>Name the four farms</h2>
      <p>Pass the device clockwise. Choices stay hidden until all four pairs lock in.</p>
      <div className="roster-grid">{localNames.map((name, index) => <label key={index}><span><img src={crestFor(index)} alt="" /> Farm {index + 1}</span><input value={name} onChange={(event) => setLocalNames((current) => current.map((item, itemIndex) => itemIndex === index ? event.target.value : item))} maxLength={28} /></label>)}</div>
      <button className="primary wide" onClick={startLocal}>Begin setup</button>
    </section></Shell>
  );

  if (!room) return null;
  if (room.phase === 'lobby') return <Waiting room={room} onLeave={restart} />;

  if (room.phase === 'setup') {
    const targetSlot = mode === 'room' ? slot : setupSlot;
    const targetFarm = room.farms.find((item) => item.slot === targetSlot)!;
    if (targetFarm.setupDone) return <Waiting room={room} onLeave={restart} message="Your farm is ready. Waiting for the other teams…" />;
    return <SetupScreen farmName={targetFarm.name} selected={needs} feedback={setupFeedback} onToggle={toggleNeed} onSubmit={submitSetup} />;
  }

  if (room.phase === 'briefing') {
    const briefingFarm = room.farms.find((item) => item.slot === (mode === 'room' ? slot : 0))!;
    return <RulesBriefing room={room} ready={mode === 'room' && briefingFarm.ready} onReady={finishBriefing} />;
  }

  if (room.phase === 'choice') {
    if (mode === 'local' && !passReady) return <PassScreen farm={farm!} season={room.season} onReady={beginLocalTurn} />;
    if (room.submissions[String(ownSlot)]) return <Waiting room={room} onLeave={restart} message="Choice locked. Consequences reveal together after the final farm locks." game />;
    if (gate) return <KnowledgeGate question={gate.question} stage={gate.stage} result={gateResult} onAnswer={answerGate} onContinue={continueGate} />;
    return <GameBoard room={room} farm={farm!} ranks={ranks} remaining={(room.deadline ?? now) - now} selectedAction={selectedAction} sabotageTarget={sabotageTarget} emote={emote} onAction={chooseAction} onTarget={setSabotageTarget} onEmote={setEmote} onLock={beginGate} />;
  }

  if (room.phase === 'results') return <Results room={room} onContinue={continueSeason} waiting={mode === 'room' && !!farm?.ready} />;
  if (room.phase === 'final' && !finaleReady) return <Results room={room} onContinue={() => setFinaleProgress({ key: finaleKey, ready: true })} waiting={false} finalSeason />;
  return <Finale room={room} onRestart={restart} />;
}

function Shell({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return <main className={`game-shell ${className}`}>{children}</main>;
}

function TitleScreen({ onRoom, onLocal, onDemo }: { onRoom: () => void; onLocal: () => void; onDemo: () => void }) {
  return <main className="title-screen">
    <div className="title-overlay"><p className="eyebrow">Lower Secondary Science · Sources of Food</p><h1>Farm Wars</h1><p>Four farms. One river. Five seasons.</p><strong className="title-promise">Grow food, outplay your rivals and survive the consequences you share.</strong><div className="title-actions"><button className="primary" onClick={onRoom}>Start multiplayer room</button><button className="secondary" onClick={onDemo}>Open teacher demo</button></div><button className="fallback-link" onClick={onLocal}>School Wi-Fi down? Use one-device pass &amp; play →</button><small>Recommended: 4 pairs · 4 devices · one shared room code</small></div>
  </main>;
}

function Waiting({ room, onLeave, message = 'Waiting for every farm to join…', game = false }: { room: RoomState; onLeave: () => void; message?: string; game?: boolean }) {
  return <Shell className={game ? 'with-valley' : ''}>
    {game && <Valley room={room} />}
    <section className="wood-panel waiting-panel"><button className="text-button" onClick={onLeave}>Leave room</button><p className="eyebrow">Shared server room</p><div className="room-code">{room.code}</div><h2>{message}</h2><p className="room-instruction">Each pair should open the game on its own laptop or tablet and enter this code. Choices stay private, then reveal on every screen together.</p><div className="farm-slots">{Array.from({ length: room.pairCount }, (_, index) => { const farm = room.farms.find((item) => item.slot === index); return <div className={farm ? 'claimed' : ''} key={index}><img src={crestFor(index)} alt="" /><strong>{farm?.name ?? `Farm ${index + 1}`}</strong><span>{farm ? farm.setupDone ? 'Ready' : 'Joined on device' : 'Waiting for device'}</span></div>; })}</div></section>
  </Shell>;
}

function SetupScreen({ farmName, selected, feedback, onToggle, onSubmit }: { farmName: string; selected: string[]; feedback: string; onToggle: (id: string) => void; onSubmit: () => void }) {
  return <Shell><section className="wood-panel setup-panel"><p className="eyebrow">Farm setup · {farmName}</p><h2>Choose the five things a plant needs to grow well.</h2><p>Every team begins equally with <b>4 plots</b>. Wrong answers can be corrected before play begins.</p><p className="selection-count">Selected {selected.length} / 5</p><div className="needs-grid">{NEEDS.map((need) => <button key={need.id} className={selected.includes(need.id) ? 'selected' : ''} onClick={() => onToggle(need.id)}><img src={`/assets/icons/${need.art}.png`} alt="" /><span>{need.label}</span></button>)}</div><button className="primary wide" disabled={selected.length !== 5} onClick={onSubmit}>Check my five choices</button>{feedback && <p className="feedback" role="status">{feedback}</p>}</section></Shell>;
}

function RulesBriefing({ room, ready, onReady }: { room: RoomState; ready: boolean; onReady: () => void }) {
  return <Shell className="briefing-shell"><section className="wood-panel briefing-panel"><div className="briefing-title"><p className="eyebrow">Read this before season 1</p><h2>How to win Farm Wars</h2><p>Grow enough food to feed your village—but remember: every farm shares the same river and sky.</p></div>
    <div className="win-rule"><div className="trophy-icon">🏆</div><div><span>Main winner</span><h3>Best Overall Score</h3><p className="big-equation">Crops <b>− 2× river</b> <b>− 4× haze</b> <b>− 2× soil residue</b> <b>− 2× welfare harm</b> <b>− 1× missed village target</b></p><small>Every card is free to choose, but its biological and environmental costs can erase a high harvest — and each season the village goes unfed costs 1 point.</small></div></div>
    <div className="briefing-grid"><article><span className="rule-number">1</span><h3>Start equally</h3><p>Every farm begins with <b>4 plots</b>. There is no money: cards are balanced by what they do to crops, soil, water, air and animals.</p></article><article><span className="rule-number">2</span><h3>Read the random event</h3><p>Each room receives a shuffled five-season deck containing calm weather, poor soil, locusts and weeds. The event appears <b>before</b> you choose.</p></article><article><span className="rule-number">3</span><h3>Choose for a reason</h3><ol><li>Read exactly what the event will damage</li><li>Find the cards scientifically matched to that event</li><li>Predict each hidden consequence</li><li>Reveal and compare every farm after all teams lock</li></ol></article><article><span className="rule-number">4</span><h3>Watch shared pollution</h3><p>River and haze belong to everyone. A bloom removes crops and livestock food; heavy haze makes every farm recover next season.</p><div className="shared-meter-demo"><span>💧 River → algal bloom</span><span>☁️ Haze → masks and forced recovery</span></div></article><article><span className="rule-number">5</span><h3>Do nothing strategically</h3><p>It does not control today’s event, but removes 1 soil residue and gives every plot <b>+1 crop next season</b>. Calm weather is the safest time to recover.</p></article><article><span className="rule-number">6</span><h3>Sabotage is optional</h3><p>Each team has one ⚡ attempt. A correct hard science answer spoils up to {GAME_RULES.sabotageCropLoss} rival crops. A wrong answer cancels your own action.</p></article></div>
    <div className="three-awards"><div><span>🌿</span><b>Cleanest Farmer</b><small>Least river + haze</small></div><div><span>🌾</span><b>Highest Yield</b><small>Most total crops</small></div><div><span>🔬</span><b>Sharpest Scientists</b><small>Most first-try correct answers</small></div><div className="main-award"><span>🏆</span><b>Best Overall</b><small>Crops minus consequences</small></div></div>
    <div className="briefing-ready"><p>{room.pairCount > 1 ? 'Every team must press ready. Season 1 starts together.' : 'Season 1 begins when you are ready.'}</p><button className="primary" disabled={ready} onClick={onReady}>{ready ? 'Ready — waiting for other teams…' : 'We understand · start season 1'}</button></div>
  </section></Shell>;
}

function PassScreen({ farm, season, onReady }: { farm: RoomState['farms'][number]; season: number; onReady: () => void }) {
  return <Shell><section className="wood-panel pass-panel"><img src={crestFor(farm.slot)} alt="" /><p className="eyebrow">Season {season} · Private choice</p><h2>Pass the device to {farm.name}</h2><p>Other farms: look away. Their card and answer must stay secret.</p><button className="primary" onClick={onReady}>We have the device</button></section></Shell>;
}

function Valley({ room }: { room: RoomState }) {
  const hazeEvent = room.events.some((event) => event.kind === 'haze') || room.farms.some((farm) => farm.forcedNext);
  const algalEvent = room.events.some((event) => event.kind === 'algal') || room.algalUntilSeason >= room.season;
  const sky = hazeEvent ? '3.7' : room.haze <= 2 ? '3.5' : '3.6';
  const river = algalEvent ? '3.4' : room.river <= 3 ? '3.2' : '3.3';
  const burns = room.farms.reduce((sum, farm) => sum + farm.history.filter((item) => item.action === 'SLASH_BURN' || item.action === 'EMERGENCY_CLEARING').length, 0);
  const forest = burns === 0 ? '3.8' : burns <= 2 ? '3.9' : '3.10';
  return <div className="valley" aria-label="The shared valley"><img src={`/assets/valley/${sky}.png`} alt="" /><img src={`/assets/valley/${forest}.png`} alt="" /><img src="/assets/valley/3.1.png" alt="" /><img src={`/assets/valley/${river}.png`} alt="" /></div>;
}

function FarmScene({ farm, season, threat, compact = false, previewAction = null, airUnsafe = false, waterPolluted = false }: { farm: RoomState['farms'][number]; season: number; threat: ThreatDefinition; compact?: boolean; previewAction?: ActionId | null; airUnsafe?: boolean; waterPolluted?: boolean }) {
  const last = farm.history.at(-1);
  const isDiscussionPreview = previewAction !== null;
  const resolvedThisSeason = last?.season === season;
  const actionIsCurrent = isDiscussionPreview || resolvedThisSeason;
  const action = previewAction ?? (last?.season === season ? last.action : 'DO_NOTHING');
  const consequenceIsRevealed = !isDiscussionPreview && resolvedThisSeason;
  const cropBoostIsRevealed = consequenceIsRevealed && ['IMPROVED_PLANT', 'HORMONE_RIPEN', 'FERTILISER'].includes(action);
  const cropStage = farm.plantBonus > 0 || cropBoostIsRevealed ? 3 : farm.history.length === 0 ? 1 : last?.met ? 3 : 2;
  const actionUsesFire = action === 'SLASH_BURN' || action === 'EMERGENCY_CLEARING';
  const applicationVisible = ['FERTILISER', 'PESTICIDE', 'HERBICIDE'].includes(action);
  const isBurning = consequenceIsRevealed && actionUsesFire;
  const chemicals = consequenceIsRevealed && applicationVisible;
  const burnCount = farm.history.filter((item) => item.action === 'SLASH_BURN' || item.action === 'EMERGENCY_CLEARING').length;
  const previewExtraPlots = 0;
  const displayPlots = farm.plots + previewExtraPlots;
  const showLivestock = farm.livestockYield > 0;
  const showBio = farm.hasBioControl;
  const intensive = farm.usedActions.includes('INTENSIVE');
  const unsafeAir = isBurning || airUnsafe;
  const dirtyRiver = chemicals || waterPolluted;
  const soilRisk = farm.soilContamination > 0;
  const locustsVisible = threat.id === 'LOCUSTS' && !showBio && !(consequenceIsRevealed && action === 'PESTICIDE');
  const weedsVisible = threat.id === 'WEEDS' && !(consequenceIsRevealed && ['HERBICIDE', 'HORMONE_WEED'].includes(action));
  const currentPlotLabel = `${farm.plots} plot${farm.plots === 1 ? '' : 's'}`;
  const plotLabel = previewExtraPlots > 0 ? `${farm.plots} → ${displayPlots} plots` : currentPlotLabel;
  const plotColumns = compact ? Math.min(4, Math.max(2, displayPlots)) : displayPlots <= 4 ? 2 : Math.min(4, displayPlots);
  const runoffLabel = action === 'FERTILISER' ? 'NUTRIENT RUNOFF →' : action === 'PESTICIDE' ? 'PESTICIDE RESIDUE →' : 'HERBICIDE RUNOFF →';
  const projectedPlot = consequenceIsRevealed && last ? { perPlot: last.perPlotYield, formula: last.plotFormula } : projectPlotYield(farm, action, threat.id);
  const plotExplanation = projectedPlot.formula.join(' ');
  return <section className={`farm-scene ${compact ? 'compact' : ''} action-${action.toLowerCase()} ${unsafeAir ? 'air-unsafe' : ''} ${dirtyRiver ? 'river-dirty' : ''} ${soilRisk ? 'soil-risk' : ''}`} aria-label={`${farm.name}'s farm with ${currentPlotLabel}`}>
    <header><span><img src={crestFor(farm.slot)} alt="" /><strong>{farm.name}</strong>{previewAction && <em>LIVE PREVIEW</em>}</span><b>{plotLabel}</b></header>
    <div className="farm-world">
      <div className="farm-sky"><i className="farm-sun" /><i className="cloud cloud-one" /><i className="cloud cloud-two" />{unsafeAir && <div className="haze-veil" />}{isBurning && <>{Array.from({ length: 8 }, (_, index) => <i className={`smoke smoke-${index + 1}`} key={index} />)}</>}</div>
      <div className={`tree-line burn-level-${Math.min(3, burnCount)}`} aria-label={burnCount ? 'Cleared forest with missing and charred trees' : 'Healthy forest edge'}>{Array.from({ length: 7 }, (_, index) => <img src="/assets/sprites/2.4.png" alt="" key={index} />)}</div>
      <div className="farm-barn"><i /><span /></div><div className="farm-fence" />
      <div className={`distant-water ${dirtyRiver ? 'polluted' : ''}`} aria-hidden="true"><i /><i /></div>
      <div className={`farm-river ${dirtyRiver ? 'polluted' : ''}`}><i /><i /><i />{dirtyRiver && <span className="river-sludge" />}</div>
      {chemicals && <div className="runoff-stream"><i /><b>{runoffLabel}</b></div>}
      <div className="plot-grid" style={{ gridTemplateColumns: `repeat(${plotColumns}, 1fr)` }}>
        {Array.from({ length: displayPlots }, (_, index) => <div tabIndex={0} aria-label={`Plot ${index + 1}: ${plotExplanation}`} className={`farm-plot crop-stage-${cropStage} ${index >= farm.plots ? 'ghost-plot' : ''} ${index >= farm.plots - farm.erosionAmount && index < farm.plots && farm.erosionDueSeason ? 'erosion-watch' : ''}`} key={index}><span className="crop-layer" />{soilRisk && index % 2 === 0 && <span className="soil-stain" />}{weedsVisible && <img className="plot-weeds" src="/assets/sprites/2.6.png" alt="Weeds competing with crops" />}{consequenceIsRevealed && action === 'HORMONE_RIPEN' && <img className="ripe-fruit" src="/assets/sprites/2.12.png" alt="Ripe fruit" />}{isBurning && index >= displayPlots - (action === 'EMERGENCY_CLEARING' ? 3 : 2) && <span className="ember" />}{index >= farm.plots && <b>+ NEW</b>}<span className="plot-yield-tooltip" role="tooltip"><strong>{projectedPlot.perPlot} crop{projectedPlot.perPlot === 1 ? '' : 's'} from this plot</strong><span>{projectedPlot.formula.join(' ')}</span><small>Plot yield only; livestock and one-off fruit bonuses are added separately.</small></span></div>)}
      </div>
      <img className={`field-workers ${unsafeAir ? 'masked' : ''}`} src={unsafeAir ? '/assets/characters/farm-workers-masked.png' : '/assets/characters/farm-workers.png'} alt={unsafeAir ? 'Three farm workers wearing masks; one is coughing in unhealthy air' : 'Three farm workers watering, hoeing and harvesting the fields'} />
      {showLivestock && <><img className="farm-animal animal-one" src="/assets/sprites/2.8.png" alt="Chicken" /><img className="farm-animal animal-two" src="/assets/sprites/2.10.png" alt="Cattle" />{intensive && <><img className="farm-animal animal-three" src="/assets/sprites/2.8.png" alt="Crowded chicken" /><div className="welfare-warning">CROWDED PEN</div></>}</>}
      {showBio && <img className="bio-bird" src="/assets/sprites/2.5.png" alt="Predator used for biological control" />}
      {applicationVisible && <div className="farm-particles">{Array.from({ length: 8 }, (_, index) => <i key={index} />)}</div>}
      {locustsVisible && <div className="locust-swarm" aria-label="Pixel-art locusts running through the crops">{Array.from({ length: 7 }, (_, index) => <img src="/assets/creatures/locust.png" alt="" key={index} />)}<b>LOCUSTS IN THE CROPS</b></div>}
      {farm.soilContamination > 0 && <div className="soil-warning">Soil residues {farm.soilContamination}/4</div>}
      <div className="impact-flags">{burnCount > 0 && <strong className="flag-burn">TREE LOSS · {burnCount} clearing</strong>}{dirtyRiver && <strong className="flag-water">POLLUTED WATER</strong>}{unsafeAir && <strong className="flag-air">MASKS ON · UNHEALTHY AIR</strong>}{farm.pollinatorDamage > 0 && <strong className="flag-erosion">POLLINATORS HARMED · −1/PLOT</strong>}{threat.id === 'LOCUSTS' && (showBio || (consequenceIsRevealed && action === 'PESTICIDE')) && <strong className="flag-solved">LOCUSTS CONTROLLED</strong>}{threat.id === 'WEEDS' && consequenceIsRevealed && ['HERBICIDE', 'HORMONE_WEED'].includes(action) && <strong className="flag-solved">WEEDS CONTROLLED</strong>}{farm.erosionDueSeason && <strong className="flag-erosion">EROSION DUE S{farm.erosionDueSeason}</strong>}</div>
      {previewAction && <div className="preview-impact"><span>Selected for discussion</span><strong>{actionById(previewAction).gain}</strong><p>Hover or focus a plot to see the science-linked yield calculation. What hidden consequence might follow?</p><small>The class consequences stay hidden until every farm locks.</small></div>}
    </div>
    <footer><div><span>Latest harvest</span><strong>{last?.harvest ?? 0} crops</strong><div className="harvest-bar"><i style={{ width: `${Math.min(100, ((last?.harvest ?? 0) / (DEMAND[Math.max(0, season - 1)] || 1)) * 100)}%` }} /></div></div><div><span>Farm total</span><strong>{farm.totalCrops}</strong></div><div><span>Soil residues</span><strong>{farm.soilContamination}/{GAME_RULES.soilThreshold}</strong></div><div><span>Overall now</span><strong>{finalScore(farm)}</strong></div></footer>
    {actionIsCurrent && <div className="farm-action-caption"><img src={actionArt(action)} alt="" /><span><b>{previewAction ? `Discuss: ${actionById(action).name}` : actionById(action).name}</b>{previewAction ? 'Predict the consequence with your partner. The answer will appear only after all teams finish.' : LEARNING_NOTES[action]}</span></div>}
  </section>;
}

function GameBoard({ room, farm, ranks, remaining, selectedAction, sabotageTarget, emote, onAction, onTarget, onEmote, onLock }: {
  room: RoomState; farm: RoomState['farms'][number]; ranks: RoomState['farms']; remaining: number; selectedAction: ActionId | null;
  sabotageTarget: number | null; emote: number | null; onAction: (id: ActionId) => void; onTarget: (slot: number | null) => void; onEmote: (id: number | null) => void; onLock: () => void;
}) {
  const [actionGroup, setActionGroup] = useState<(typeof ACTION_GROUPS)[number]['id']>('quick');
  const selectedGroup = ACTION_GROUPS.find((group) => group.id === actionGroup)!;
  const visibleActions = ACTIONS.filter((action) => selectedGroup.actions.includes(action.id));
  const threat = threatFor(room);
  const myRank = ranks.findIndex((item) => item.slot === farm.slot) + 1;
  const selectedDefinition = selectedAction ? actionById(selectedAction) : null;
  return <Shell className="board-shell"><Valley room={room} /><header className="hud"><div><span>Season {room.season}/5 · Random event</span><strong>{threat.icon} {threat.name}</strong></div><div className="meter-group"><Meter label="River" value={room.river} cap={2 * room.pairCount} /><Meter label="Haze" value={room.haze} cap={Math.ceil(1.5 * room.pairCount)} /></div><div className="timer">{formatTime(remaining)}</div></header>
    <details className="standings-drawer"><summary><span>Class standings</span><strong>You are #{myRank}</strong><em>View all four farms</em></summary><aside className="rank-strip" aria-label="Best Overall score standings">{ranks.map((item, index) => <div key={item.slot} className={item.slot === farm.slot ? 'you' : ''}><span className={`rank rank-${index + 1}`}>{index + 1}</span><img src={crestFor(item.slot)} alt="" /><span>{item.name}</span><strong>{finalScore(item)} overall · {item.totalCrops} food</strong></div>)}</aside></details>
    <section className="learning-mission"><span>Mission</span><strong>{missionFor(threat)}</strong><p>{room.season === 3 ? 'Match-the-event hints are off from this season. Read event → predict → choose → compare.' : 'Read event → predict → choose → compare.'}</p></section>
    <section className={`world-event-alert event-${threat.id.toLowerCase()}`}><div>{threat.icon}</div><p><span>World event revealed before discussion</span><strong>{threat.name}</strong><b>{threat.penalty}</b><small>{threat.science}</small></p></section>
    <section className="farm-overview"><FarmScene farm={farm} season={room.season} threat={threat} previewAction={selectedAction} airUnsafe={farm.forcedNext || room.haze > 2} waterPolluted={room.river > 3 || room.algalUntilSeason >= room.season} /></section>
    <section className="choice-panel">{farm.forcedNext && <div className="forced-banner">☁️ Forced recovery: heavy shared haze has locked every action except Do nothing / recover this season.</div>}<div className="choice-heading"><div><p className="eyebrow">Step 1 of 4 · {farm.name}</p><h2>Choose one response</h2></div><div className="decision-chips"><span>Target <b>{DEMAND[room.season - 1]} crops</b></span><span>Land <b>{farm.plots} plots</b></span><span>Soil <b>{farm.soilContamination}/{GAME_RULES.soilThreshold} residues</b></span></div></div>
      <nav className="action-tabs" aria-label="Action categories">{ACTION_GROUPS.map((group) => <button key={group.id} className={actionGroup === group.id ? 'selected' : ''} onClick={() => setActionGroup(group.id)}><strong>{group.label}</strong><span>{group.hint}</span></button>)}</nav>
      <div className="card-grid">{visibleActions.map((action) => { const locked = isActionLocked(farm, action); const selected = selectedAction === action.id; const matched = !!action.counters?.includes(threat.id) && room.season <= 2; return <button key={action.id} className={`action-card ${selected ? 'selected' : ''} ${matched ? 'event-match' : ''}`} disabled={!!locked} onClick={() => onAction(action.id)} title={locked ?? `Choose ${action.name}`} aria-label={`${action.name}. Intended benefit: ${action.gain}. ${matched ? `Scientifically matches ${threat.name}.` : ''} Consequence hidden until the class reveal.`}><img src={`/assets/cards/${action.art}.png`} alt="" />{matched && <span className="event-match-badge">✓ Matches this event</span>}<span className="card-title-row"><b className="card-name">{action.name}</b></span><span className="card-gain"><b>What it can do</b>{action.gain}</span><span className="card-mystery">❓ Biological consequence revealed after all teams lock</span>{selected && <span className="card-selected">✓ Selected</span>}{locked && <span className="lock">🔒 {locked}</span>}</button>; })}</div>
      {selectedDefinition && <section className="selected-action-summary" aria-live="polite"><img src={actionArt(selectedDefinition.id)} alt="" /><div><span>Selected for discussion</span><h3>{selectedDefinition.name}</h3><p><b>Expected response:</b> {selectedDefinition.gain}</p><p className="selected-prediction"><b>Predict before locking:</b> What might happen to crops, soil, people, animals, the river, or the sky?</p></div></section>}
      <div className="competitive-tools"><details className="optional-tools"><summary>Optional competitive move: sabotage or send a taunt</summary><div className="optional-tools-body"><div className={`sabotage-console ${sabotageTarget !== null ? 'armed' : ''}`}><div><span className="sabotage-token">⚡ {farm.sabotageTokens}</span><strong>Optional sabotage · affects this reveal</strong><small>Your one token risks your own action. A correct hard science answer spoils up to {GAME_RULES.sabotageCropLoss} rival crops; a wrong answer cancels your action. Multiple hits do not stack.</small></div><div className="rival-targets"><button className={sabotageTarget === null ? 'selected' : ''} onClick={() => onTarget(null)}>No sabotage</button>{room.farms.filter((item) => item.slot !== farm.slot).map((item) => <button key={item.slot} disabled={!farm.sabotageTokens} className={sabotageTarget === item.slot ? 'selected' : ''} onClick={() => onTarget(item.slot)}><img src={crestFor(item.slot)} alt="" /><span>{item.name}</span></button>)}</div></div><label className="taunt-picker">Send one taunt<select value={emote ?? ''} onChange={(event) => onEmote(event.target.value === '' ? null : Number(event.target.value))}><option value="">No emote</option>{[19, 20, 21, 22, 23, 24, 25].map((id) => <option key={id} value={id}>Emote {id - 18}</option>)}</select></label></div></details><div className="lock-summary"><span>{selectedAction ? actionById(selectedAction).name : 'Choose a card above'}</span>{sabotageTarget !== null && <small>⚡ One sabotage token armed</small>}<button className="primary" disabled={!selectedAction} onClick={onLock}>Answer science &amp; lock</button></div></div>
    </section>
  </Shell>;
}

function Meter({ label, value, cap }: { label: string; value: number; cap: number }) { return <div className="meter"><span>{label}</span><div><i style={{ width: `${Math.min(100, value / cap * 100)}%` }} /></div><b>{value}/{cap}</b></div>; }

function KnowledgeGate({ question, stage, result, onAnswer, onContinue }: { question: Question; stage: GateStage; result: GateResult | null; onAnswer: (answer: string) => void; onContinue: () => void }) {
  const resultTitle = result?.correct
    ? stage === 'sabotage' ? 'Correct — sabotage will appear in this reveal.' : result.corrected ? 'Corrected — now explain the link.' : 'Correct — your scientific reasoning supports the choice.'
    : `Not quite. The answer is: ${question.answer}`;
  const continueLabel = result?.after === 'card' ? 'Now answer your card question' : result?.after === 'retry' ? 'Try this question again' : result?.correct === false && stage === 'sabotage' ? 'Accept the backfire & lock' : 'Lock this choice';
  return <Shell><section className="wood-panel gate-panel"><img src={`/assets/icons/${stage === 'sabotage' ? '7.14' : '7.13'}.png`} alt="" /><p className="eyebrow">{stage === 'sabotage' ? 'Optional sabotage · this season' : 'Explain your choice'}</p><h2>{question.prompt}</h2><div className="answers">{question.options.map((option) => <button key={option} disabled={!!result} className={result && option === question.answer ? 'answer-correct' : ''} onClick={() => onAnswer(option)}>{option}</button>)}</div>{result ? <div className={`learning-feedback ${result.correct ? 'correct' : 'incorrect'}`}><strong>{resultTitle}</strong><p>{result.explanation}</p>{result.corrected && <p>The biological outcome does not change after a retry—the science model stays consistent.</p>}<button className="primary" onClick={onContinue}>{continueLabel}</button></div> : <p>{stage === 'sabotage' ? 'One token only. A wrong answer cancels your own farm action.' : 'Use the science to defend your prediction. The farm and environmental consequences appear only after every team locks.'}</p>}</section></Shell>;
}

function FarmConsequence({ farm, room }: { farm: RoomState['farms'][number]; room: RoomState }) {
  const history = farm.history.at(-1)!;
  const action = actionById(history.action);
  const effects = [action.consequence];
  if (!history.gateCorrect && !history.sabotageFailed) effects.push('Science answer corrected after feedback: the biological model stayed the same.');
  if (history.sabotageFailed) effects.push(`Sabotage backfired: ${actionById(history.attemptedAction ?? 'DO_NOTHING').name} was cancelled.`);
  if ((history.sabotageLoss ?? 0) > 0) {
    const names = (history.sabotagedBy ?? []).map((slot) => room.farms.find((item) => item.slot === slot)?.name).filter(Boolean).join(' and ');
    effects.push(`Sabotaged by ${names || 'a rival'}: ${history.sabotageLoss} crops were spoiled before the harvest was counted.`);
  }
  if (!history.met) effects.push('Village target missed: −1 overall point. A second consecutive miss unlocks Emergency Clearing.');
  if (history.recoveryApplied > 0) effects.push(`Low-input recovery removed ${history.recoveryApplied} soil residue; rested soil gives +1 crop per plot next season.`);
  if (history.soilEvent) effects.push('Chemical residues reached 4: this harvest was halved before residues fell back to 1.');
  if (room.events.some((event) => event.kind === 'erosion' && event.slots?.includes(farm.slot))) effects.push('Delayed erosion arrived: unprotected topsoil and the promised new land washed away.');
  return <article className="consequence-card"><header><img src={crestFor(farm.slot)} alt="" /><div><span>{farm.name}</span><strong>{action.name}</strong></div><b>{history.harvest} crops</b></header><div className="action-benefit"><span>Expected response</span><strong>{action.gain}</strong></div><div className="plot-equation"><span>Each plot</span><strong>{history.plotFormula.join(' ')}</strong></div><div className="harvest-equation" aria-label="Harvest calculation"><span>Plots <b>{history.plotHarvest}</b><small>{farm.plots} × {history.perPlotYield}</small></span>{history.livestockHarvest > 0 && <em>+ animals <b>{history.livestockHarvest}</b></em>}{history.ripeningGain > 0 && <em>+ ripening <b>{history.ripeningGain}</b></em>}<i>− shared event <b>{history.sharedEventLoss}</b></i><i>− soil event <b>{history.soilLoss}</b></i><i>− sabotage <b>{history.sabotageLoss}</b></i><strong>= {history.harvest} food</strong></div><ul>{effects.map((effect, index) => <li key={index}>{effect}</li>)}</ul></article>;
}

function Results({ room, onContinue, waiting, finalSeason = false }: { room: RoomState; onContinue: () => void; waiting: boolean; finalSeason?: boolean }) {
  const ranks = rankFarms(room.farms);
  const threat = threatFor(room);
  const [revealed, setRevealed] = useState(0);
  const totalFarms = room.farms.length;
  const allRevealed = revealed >= totalFarms;
  useEffect(() => {
    if (allRevealed) return;
    const timer = window.setTimeout(() => setRevealed((value) => value + 1), revealed === 0 ? 700 : 1200);
    return () => window.clearTimeout(timer);
  }, [revealed, allRevealed]);
  const previous = rankFarms(room.farms.map((farm) => {
    const history = farm.history.at(-1)!;
    return { ...farm, history: farm.history.slice(0, -1), totalCrops: farm.totalCrops - history.harvest, riverContributed: farm.riverContributed - history.river, hazeContributed: farm.hazeContributed - history.haze, ethicsCost: farm.ethicsCost - actionById(history.action).ethics };
  }));
  const movers = ranks.filter((farm, index) => previous.findIndex((item) => item.slot === farm.slot) > index);
  const droppedLast = ranks.length > 1 && previous.findIndex((item) => item.slot === ranks.at(-1)!.slot) < ranks.length - 1 ? ranks.at(-1) : null;
  const airUnsafe = room.haze > 2 || room.events.some((event) => event.kind === 'haze');
  const waterPolluted = room.river > 3 || room.events.some((event) => event.kind === 'algal') || room.algalUntilSeason >= room.season;
  const visibleEvents = Array.from(new Map(room.events.map((event) => [event.kind, event])).values());
  const causeSteps = visibleEvents.flatMap((event, eventIndex) => EVENT_CHAINS[event.kind].map(([id, caption], panelIndex) => ({ key: `${eventIndex}-${panelIndex}`, image: id === '6.18' ? '/assets/misc/6_18.png' : `/assets/chains/${id}.png`, caption })));
  return <Shell className="results-shell"><section className="wood-panel ledger"><p className="eyebrow">Season {room.season} · {threat.icon} {threat.name} · Simultaneous reveal</p><h2>All four farms reveal together</h2><p className="reveal-intro">Discussion is over. Compare how each response changed plot yield and what biological consequence followed.</p><div className="reveal-row">{room.farms.map((farm, index) => { if (index >= revealed) return <div key={farm.slot} className="card-facedown"><div className="reveal-card reveal-back" aria-label={`${farm.name}'s choice is still hidden`}>❓</div><span><img src={crestFor(farm.slot)} alt="" />{farm.name}</span><strong>Locked in…</strong></div>; const history = farm.history.at(-1)!; const target = history.sabotageTarget === null ? null : room.farms.find((item) => item.slot === history.sabotageTarget); return <div key={farm.slot} className="card-revealed"><img className="reveal-card" src={actionArt(history.action)} alt={actionById(history.action).name} /><span><img src={crestFor(farm.slot)} alt="" />{farm.name}</span><strong>{actionById(history.action).name}</strong>{target && <em>⚡ Hit {target.name}’s harvest</em>}{history.sabotageFailed && <em>⚡ Backfired · action cancelled</em>}</div>; })}</div>{!allRevealed && <button className="secondary reveal-skip" onClick={() => setRevealed(totalFarms)}>Skip to full results →</button>}{allRevealed && <><h3 className="section-label">Yield calculation and actual consequences — compare every team</h3><div className="consequence-grid">{room.farms.map((farm) => <FarmConsequence key={farm.slot} farm={farm} room={room} />)}</div>{(movers.length > 0 || droppedLast) && <div className="overtake-alerts">{movers.map((item) => <span className="climbed" key={item.slot}>▲ {item.name} climbed the ranks!</span>)}{droppedLast && <span className="dropped">✦ {droppedLast.name} dropped to last</span>}</div>}<p className="eyebrow ledger-title">The shared environment</p><h2>Who put what into our river and sky?</h2><div className="ledger-table"><div className="ledger-head"><span>Farm</span><span>This river</span><span>Total river</span><span>This haze</span><span>Total haze</span><span>Harvest / Soil</span></div>{room.farms.map((farm) => { const row = room.ledgerSeason.find((item) => item.slot === farm.slot)!; const history = farm.history.at(-1)!; return <div key={farm.slot}><span className="farm-cell"><img src={crestFor(farm.slot)} alt="" /><b>{farm.name}</b></span><span>+{row?.river ?? 0}</span><span>{farm.riverContributed}</span><span>+{row?.haze ?? 0}</span><span>{farm.hazeContributed}</span><span className={history.met ? 'met' : 'missed'}>{history.harvest} {history.met ? '✓' : 'MISS'} · soil {farm.soilContamination}/{GAME_RULES.soilThreshold}</span></div>; })}</div>
      {visibleEvents.length > 0 && <div className="event-banners">{visibleEvents.map((event) => <span key={event.kind} className={event.kind}>{event.kind === 'algal' ? event.ongoing ? 'Ongoing algal bloom: livestock food is still unavailable' : `Algal bloom: −${GAME_RULES.algalCropLoss} crops and all livestock food lost` : event.kind === 'haze' ? 'Haze: people need masks; every farm must recover next season' : event.kind === 'soil' ? 'Residue threshold reached: contaminated harvest halved' : 'Erosion: promised extra plots washed away'}</span>)}</div>}
      {causeSteps.length > 0 && <details className="shared-cause-chain"><summary>Why did the shared consequence happen? Open the science chain</summary><div>{causeSteps.map((step) => <figure key={step.key}><img src={step.image} alt="" /><figcaption>{step.caption}</figcaption></figure>)}</div></details>}
      <h3 className="section-label">Watch all four consequences now — they carry into the next season</h3><div className="farm-gallery">{room.farms.map((farm) => <FarmScene key={farm.slot} farm={farm} season={room.season} threat={threat} airUnsafe={airUnsafe} waterPolluted={waterPolluted} compact />)}</div>
      <div className="science-roundup"><p className="eyebrow">Science roundup</p>{room.farms.map((farm) => { const action = farm.history.at(-1)!.action; return <div key={farm.slot}><img src={crestFor(farm.slot)} alt="" /><p><strong>{farm.name}: {actionById(action).name}</strong><span>{LEARNING_NOTES[action]}</span></p></div>; })}</div>
      <div className="leaderboard"><h3>Best Overall standings</h3>{ranks.map((farm, index) => <div key={farm.slot}><span className={`rank rank-${index + 1}`}>{index + 1}</span><img src={crestFor(farm.slot)} alt="" /><strong>{farm.name}</strong><span>{finalScore(farm)} overall · {farm.totalCrops} food · soil {farm.soilContamination}/{GAME_RULES.soilThreshold} · 🔬 {scienceStars(farm)}</span>{farm.history.at(-1)?.emote && <img className="emote" src={`/assets/compete/8.${farm.history.at(-1)!.emote}.png`} alt="Taunt emote" />}{farm.isDesperate && <em>DESPERATE</em>}</div>)}</div>
      <button className="primary wide" disabled={waiting} onClick={onContinue}>{waiting ? 'Ready — waiting for other farms…' : finalSeason ? 'See final awards' : `Carry these effects into season ${room.season + 1}`}</button></>}
    </section></Shell>;
}

function Finale({ room, onRestart }: { room: RoomState; onRestart: () => void }) {
  const clean = [...room.farms].sort((a, b) => (a.riverContributed + a.hazeContributed) - (b.riverContributed + b.hazeContributed))[0];
  const yieldWinner = [...room.farms].sort((a, b) => b.totalCrops - a.totalCrops)[0];
  const overall = [...room.farms].sort((a, b) => finalScore(b) - finalScore(a))[0];
  const scientist = [...room.farms].sort((a, b) => scienceStars(b) - scienceStars(a))[0];
  const totalPollution = room.farms.reduce((sum, farm) => sum + farm.riverContributed + farm.hazeContributed, 0);
  const ruined = totalPollution >= room.pairCount * 9;
  const thriving = !ruined && totalPollution <= room.pairCount * 2;
  return <Shell className="final-shell"><div className="epilogue"><img src={`/assets/screens/${ruined ? '9.8' : thriving ? '9.7' : '9.9'}.png`} alt="" /></div><section className="wood-panel final-panel"><p className="eyebrow">The valley remembers every choice</p><h2>Three podiums</h2><div className="podiums"><Podium title="Cleanest Farmer" farm={clean} score={`${clean.riverContributed + clean.hazeContributed} pollution`} /><Podium title="Highest Yield" farm={yieldWinner} score={`${yieldWinner.totalCrops} food`} /><Podium title="Best Overall" farm={overall} score={`${finalScore(overall)} points`} /></div><div className="science-award"><span>🔬</span><div><b>Sharpest Scientists</b><small>{scientist.name} · {scienceStars(scientist)} first-try correct science answers</small></div><img src={crestFor(scientist.slot)} alt="" /></div><div className="final-scores">{room.farms.map((farm) => <div key={farm.slot}><img src={crestFor(farm.slot)} alt="" /><strong>{farm.name}</strong><span>{farm.totalCrops} food − {farm.riverContributed * 2} river − {farm.hazeContributed * 4} haze − {farm.soilContamination * 2} soil − {farm.ethicsCost * 2} welfare − {missedDemandCount(farm)} unfed = <b>{finalScore(farm)}</b></span>{farm.history.some((item) => item.burnedSeasonFive) && <em>Season 5 clearing: the delayed land loss was settled after the final harvest</em>}</div>)}</div><blockquote>Which response matched each biological problem, and when was recovery wiser than another input?</blockquote><button className="primary" onClick={onRestart}>Play another class game</button></section></Shell>;
}

function Podium({ title, farm, score }: { title: string; farm: RoomState['farms'][number]; score: string }) { return <div><span>{title}</span><img src={crestFor(farm.slot)} alt="" /><strong>{farm.name}</strong><small>{score}</small></div>; }
