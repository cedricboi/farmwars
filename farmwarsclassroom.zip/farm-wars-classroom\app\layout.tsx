import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  metadataBase: new URL(process.env.SITE_URL ?? 'http://localhost:3000'),
  title: 'Farm Wars — Classroom Science Game',
  description: 'Four farms share one river and one sky in a five-season classroom strategy game.',
  icons: { icon: '/assets/compete/8.1.png' },
  openGraph: {
    title: 'Farm Wars — Classroom Science Game',
    description: 'Four farms. One river. Five seasons to feed the valley.',
    images: [{ url: '/og.png', width: 1728, height: 917, alt: 'Farm Wars shared river valley' }],
  },
  twitter: { card: 'summary_large_image', title: 'Farm Wars', description: 'Four farms. One river. Five seasons.', images: ['/og.png'] },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
