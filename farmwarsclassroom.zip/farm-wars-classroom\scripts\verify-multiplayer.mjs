import assert from 'node:assert/strict';

const base = process.env.FARM_WARS_URL ?? 'http://localhost:3000';

async function post(body) {
  const response = await fetch(`${base}/api/rooms`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  const data = await response.json();
  if (!response.ok || data.error) throw new Error(`${body.type}: ${data.error ?? response.statusText}`);
  return data;
}

async function getState(code) {
  const response = await fetch(`${base}/api/rooms?code=${code}`);
  const data = await response.json();
  if (!response.ok || data.error) throw new Error(`get: ${data.error ?? response.statusText}`);
  return data.state;
}

const names = ['Sun Pair', 'River Pair', 'Soil Pair', 'Sky Pair'];
const crests = ['wheat', 'fish', 'hen', 'oak'];
const created = await post({ type: 'create', name: names[0], crest: crests[0], pairCount: 4 });
const sessions = [{ slot: created.slot, token: created.token }];
let state = created.state;

for (let index = 1; index < 4; index += 1) {
  const joined = await post({ type: 'join', code: state.code, name: names[index], crest: crests[index] });
  sessions.push({ slot: joined.slot, token: joined.token });
  state = joined.state;
}

assert.equal(state.phase, 'setup');
assert.equal(state.farms.length, 4);
assert.ok(state.farms.every((farm) => farm.plots === 4 && !('money' in farm)), 'All four devices receive the same four-plot farm with no money system');
assert.equal(state.threatSchedule.length, 5, 'The server gives every device one shared five-event schedule');

const wrong = await post({ type: 'setup', code: state.code, ...sessions[0], choices: ['air', 'light', 'water', 'nutrients', 'ash'] });
assert.equal(wrong.state.farms[0].setupDone, false, 'A setup misconception stays open for correction');
assert.equal(wrong.state.farms[0].plots, 4, 'A wrong setup answer never removes land');

const needs = ['air', 'light', 'water', 'nutrients', 'ph'];
const setupReplies = await Promise.all(sessions.map((session) => post({ type: 'setup', code: state.code, ...session, choices: needs })));
state = setupReplies.at(-1).state;
if (state.phase !== 'briefing') state = await getState(state.code);
assert.equal(state.phase, 'briefing');
assert.ok(state.farms.every((farm) => farm.setupDone && farm.plots === 4));

const briefingReplies = await Promise.all(sessions.map((session) => post({ type: 'briefing_ready', code: state.code, ...session })));
state = briefingReplies.find((reply) => reply.state.phase === 'choice')?.state ?? briefingReplies.at(-1).state;
if (state.phase !== 'choice') {
  state = await getState(state.code);
}
assert.equal(state.phase, 'choice');
assert.equal(state.season, 1);

const actions = ['IMPROVED_PLANT', 'SLASH_BURN', 'DO_NOTHING', 'FERTILISER'];
const submissionReplies = await Promise.all(sessions.map((session, index) => post({
  type: 'submit',
  code: state.code,
  ...session,
  submission: { action: actions[index], gateCorrect: index !== 2, sabotageTarget: null, sabotageCorrect: null, emote: null },
})));
state = submissionReplies.find((reply) => reply.state.phase === 'results')?.state ?? submissionReplies.at(-1).state;
if (state.phase !== 'results') {
  state = await getState(state.code);
}
assert.equal(state.phase, 'results', 'The four private choices reveal together');
assert.ok(state.farms.every((farm) => farm.history.length === 1));
assert.equal(state.farms[2].history[0].gateCorrect, false, 'A corrected answer is recorded without changing the biological outcome');
assert.equal(state.farms[0].history[0].gateCorrect, true, 'A first-try answer is recorded for teacher feedback');

console.log(JSON.stringify({
  checks: 'all passed',
  room: state.code,
  phase: state.phase,
  season: state.season,
  threat: state.threatSchedule[0],
  farms: state.farms.map((farm) => ({ name: farm.name, plots: farm.plots, harvest: farm.history[0].harvest, soil: farm.soilContamination })),
}, null, 2));
