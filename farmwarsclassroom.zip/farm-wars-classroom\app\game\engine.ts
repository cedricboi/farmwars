export const SCORE_MULTIPLIERS = { river: 2, haze: 4, soil: 2, ethics: 2 } as const;
export const CHOICE_TIME_MS = 120_000;
export const GAME_RULES = { sabotageCropLoss: 4, algalCropLoss: 3, soilThreshold: 4, restSoilRecovery: 1, missedDemandPenalty: 1 } as const;
export const DEMAND = [8, 10, 12, 16, 20] as const;
export const CRESTS = ['wheat', 'fish', 'hen', 'oak'] as const;
export const CREST_ART = ['/assets/compete/8.1.png', '/assets/compete/8.2.png', '/assets/compete/8.3.png', '/assets/compete/8.4.png'] as const;

export type Crest = (typeof CRESTS)[number];
export type ThreatId = 'CALM' | 'POOR_SOIL' | 'LOCUSTS' | 'WEEDS';
export type ActionId =
  | 'FERTILISER' | 'PESTICIDE' | 'HERBICIDE' | 'SLASH_BURN'
  | 'EMERGENCY_CLEARING' | 'BIO_CONTROL' | 'IMPROVED_PLANT'
  | 'IMPROVED_ANIMAL' | 'INTENSIVE' | 'HORMONE_WEED'
  | 'HORMONE_RIPEN' | 'DO_NOTHING';

export type RoomPhase = 'lobby' | 'setup' | 'briefing' | 'choice' | 'results' | 'final';

export interface ThreatDefinition {
  id: ThreatId;
  name: string;
  icon: string;
  penalty: string;
  science: string;
  counters: ActionId[];
}

export const WORLD_EVENTS: Record<ThreatId, ThreatDefinition> = {
  CALM: { id: 'CALM', name: 'Favourable growing weather', icon: '☀️', penalty: 'No event damage. A low-input season can restore soil and prepare next season.', science: 'With no urgent pest, weed or nutrient problem, adding chemicals is unnecessary.', counters: ['DO_NOTHING'] },
  POOR_SOIL: { id: 'POOR_SOIL', name: 'Mineral-poor soil', icon: '🪨', penalty: 'Unprotected plots lose 1 crop each. High-yield varieties lose 2 because they need more mineral nutrients.', science: 'Plants require mineral ions such as nitrates to make proteins and grow.', counters: ['FERTILISER'] },
  LOCUSTS: { id: 'LOCUSTS', name: 'Locust swarm', icon: '🦗', penalty: 'Unprotected plots lose 2 crops each as locusts eat leaves and young shoots.', science: 'Pesticide works immediately; established predators provide biological control without chemical residues.', counters: ['PESTICIDE', 'BIO_CONTROL'] },
  WEEDS: { id: 'WEEDS', name: 'Weed outbreak', icon: '🌿', penalty: 'Unprotected plots lose 1 crop each because weeds compete for light, water and mineral nutrients.', science: 'Selective herbicides or hormone weedkillers suppress weeds while leaving the crop growing.', counters: ['HERBICIDE', 'HORMONE_WEED'] },
};

export interface Question { prompt: string; answer: string; options: string[]; }

export interface ActionDefinition {
  id: ActionId;
  name: string;
  gain: string;
  art: string;
  river: number;
  haze: number;
  soil: number;
  ethics: number;
  consequence: string;
  counters?: ThreatId[];
  once?: boolean;
  question: Question[];
}

export interface Submission {
  action: ActionId;
  gateCorrect: boolean;
  sabotageTarget: number | null;
  sabotageCorrect: boolean | null;
  emote: number | null;
}

export interface FarmHistory {
  season: number;
  action: ActionId;
  attemptedAction: ActionId;
  gateCorrect: boolean;
  harvest: number;
  potentialHarvest: number;
  actionGain: number;
  plotHarvest: number;
  livestockHarvest: number;
  ripeningGain: number;
  perPlotYield: number;
  plotFormula: string[];
  threatLoss: number;
  threatReason: string | null;
  biodiversityLoss: number;
  establishmentLoss: number;
  soilLoss: number;
  sharedEventLoss: number;
  recoveryApplied: number;
  met: boolean;
  river: number;
  haze: number;
  soilEvent: boolean;
  burnedSeasonFive: boolean;
  emote: number | null;
  sabotageTarget: number | null;
  sabotageFailed: boolean;
  sabotagedBy: number[];
  sabotageLoss: number;
}

export interface FarmState {
  slot: number;
  token?: string;
  crest: Crest;
  name: string;
  setupDone: boolean;
  setupCorrect: boolean;
  plots: number;
  plantBonus: number;
  livestockYield: number;
  hasBioControl: boolean;
  usedActions: ActionId[];
  ashSeasonsLeft: number;
  ashBonus: number;
  restBonus: number;
  pollinatorDamage: number;
  erosionDueSeason: number | null;
  erosionAmount: number;
  soilContamination: number;
  ethicsCost: number;
  sabotageTokens: number;
  forcedNext: boolean;
  riverContributed: number;
  hazeContributed: number;
  missedDemandStreak: number;
  isDesperate: boolean;
  totalCrops: number;
  history: FarmHistory[];
  ready: boolean;
}

export interface SeasonEvent { kind: 'algal' | 'haze' | 'soil' | 'erosion'; slots?: number[]; ongoing?: boolean; }

export interface RoomState {
  code: string;
  pairCount: number;
  phase: RoomPhase;
  season: number;
  deadline: number | null;
  farms: FarmState[];
  submissions: Record<string, Submission>;
  threatSchedule: ThreatId[];
  river: number;
  haze: number;
  riverCostsRevealed: boolean;
  hazeCostsRevealed: boolean;
  algalUntilSeason: number;
  events: SeasonEvent[];
  ledgerSeason: Array<{ slot: number; river: number; haze: number }>;
  revision: number;
}

export interface PlotYieldBreakdown {
  perPlot: number;
  potentialPerPlot: number;
  threatLossPerPlot: number;
  biodiversityLossPerPlot: number;
  establishmentLossPerPlot: number;
  formula: string[];
}

const q = (prompt: string, answer: string, wrong: string[]): Question => ({ prompt, answer, options: [answer, ...wrong] });

export const ACTIONS: ActionDefinition[] = [
  { id: 'FERTILISER', name: 'Fertiliser', gain: '+2 crops per plot this season; protects mineral-poor plots', art: '4.1', river: 2, haze: 0, soil: 1, ethics: 0, counters: ['POOR_SOIL'], consequence: '+2 shared river nutrients and +1 soil residue. Excess nutrients can trigger an algal bloom.', question: [
    q('What do fertilisers add to the soil?', 'Nutrients', ['Water', 'Oxygen', 'Pesticides']),
    q('Why does a farmer add fertiliser?', 'The soil does not have enough nutrients', ['To kill weeds', 'To make soil harder', 'To clear trees']),
  ] },
  { id: 'PESTICIDE', name: 'Pesticide', gain: 'Stops a locust swarm this season', art: '4.2', river: 1, haze: 0, soil: 2, ethics: 0, counters: ['LOCUSTS'], consequence: '+1 river and +2 soil residues. Non-target insects are harmed, so every plot loses 1 crop next season.', question: [
    q('Pesticides are chemical substances that are…', 'Sprayed onto crops to destroy pests', ['Added to soil for nutrients', 'Used to clear forests', 'Produced by ripening fruit']),
    q('Which of these is a pest?', 'A rat feeding on rice', ['A ladybird', 'A weed', 'Algae']),
  ] },
  { id: 'HERBICIDE', name: 'Selective herbicide', gain: 'Stops a weed outbreak this season', art: '4.3', river: 1, haze: 0, soil: 2, ethics: 0, counters: ['WEEDS'], consequence: '+1 river and +2 soil residues. Repeated chemical use can contaminate a later harvest.', question: [
    q('Selective herbicides are designed to destroy…', 'Weeds while leaving the crop unharmed', ['Pests while leaving the crop unharmed', 'Algae in rivers', 'Tree stumps']),
    q('How do weeds reduce a farmer’s crop?', 'They compete for nutrients', ['They feed on crops', 'They block rain', 'They poison soil']),
  ] },
  { id: 'SLASH_BURN', name: 'Slash-and-burn', gain: '+2 plots now; ash adds +1 crop per plot for 2 seasons', art: '4.4', river: 0, haze: 3, soil: 0, ethics: 0, consequence: '+3 shared haze. Without roots, both new plots are lost to erosion two seasons later.', once: true, question: [
    q('In slash-and-burn, what happens to the trees?', 'They are cut down and burned', ['They are replanted', 'They are sprayed', 'They remain standing']),
    q('Why do ashes help the next crop?', 'They provide nutrients to soil', ['Smoke keeps pests away', 'They hold water', 'They lower soil pH']),
  ] },
  { id: 'EMERGENCY_CLEARING', name: 'Emergency Clearing', gain: '+3 plots now; ash adds +1 crop per plot', art: '4.5', river: 0, haze: 4, soil: 0, ethics: 0, consequence: '+4 shared haze. All three new plots wash away two seasons later.', once: true, question: [
    q('Why can clearing forest increase crop land?', 'It exposes land for planting', ['It creates rain', 'It removes river pollution', 'It makes sunlight stronger']),
    q('What long-term problem follows large-scale forest clearing?', 'Soil erosion, because roots no longer hold the topsoil', ['Rainfall stops completely', 'The soil stays fertile forever', 'Weeds can no longer grow']),
  ] },
  { id: 'BIO_CONTROL', name: 'Biological control', gain: 'Stops locusts now and in every later season', art: '4.6', river: 0, haze: 0, soil: 0, ethics: 0, counters: ['LOCUSTS'], consequence: 'Predator habitat takes field space during establishment: −1 crop per plot this season, then permanent locust protection.', once: true, question: [
    q('What is biological control?', 'Using predators to control pests', ['Spraying chemicals', 'Burning fields', 'Breeding larger crops']),
    q('Why does it reduce pesticide use?', 'Predators kill pests instead', ['Pests grow slower', 'Crops taste bad', 'Pests wash away']),
  ] },
  { id: 'IMPROVED_PLANT', name: 'Improved plant variety', gain: '+1 crop per plot from this season onward', art: '4.7', river: 0, haze: 0, soil: 0, ethics: 0, consequence: 'Higher-yield plants need more mineral nutrients: a future mineral-poor event costs 2 crops per plot unless fertilised.', once: true, question: [
    q('Improved plant seedlings grow into…', 'Bigger and better crops', ['Plants needing no water', 'Plants that kill weeds', 'Plants that never ripen']),
    q('How are improved crop varieties usually produced?', 'By breeding plants with desirable characteristics', ['By spraying pesticides on seeds', 'By adding ash to the soil', 'By ripening fruit faster']),
  ] },
  { id: 'IMPROVED_ANIMAL', name: 'Improved animal variety', gain: '+3 livestock food every season', art: '4.8', river: 0, haze: 0, soil: 0, ethics: 0, consequence: 'Livestock manure adds +1 river pollution every season. An algal bloom removes all livestock food.', once: true, question: [
    q('Improved animal varieties can produce…', 'Higher-quality meat or more milk', ['Their own food', 'Fewer offspring', 'Natural pesticides']),
    q('How are improved animal varieties usually produced?', 'By breeding animals with desirable characteristics', ['By feeding them herbicides', 'By keeping them in crowded pens', 'By adding fertiliser to their food']),
  ] },
  { id: 'INTENSIVE', name: 'Intensive farming', gain: 'Livestock food rises from 3 to 6 each season', art: '4.9', river: 0, haze: 0, soil: 0, ethics: 3, consequence: 'Crowding causes +3 welfare harm when adopted, and concentrated manure adds +2 river pollution every season.', once: true, question: [
    q('Intensive farming methods are used for…', 'Crops and farm animals', ['Weeds and pests', 'Algae in rivers', 'Forest trees']),
    q('What is one concern about intensive animal farming?', 'Crowded animals raise welfare and disease concerns', ['Animals produce less food', 'It stops algal blooms', 'It uses no land at all']),
  ] },
  { id: 'HORMONE_WEED', name: 'Hormone weedkiller', gain: 'Stops a weed outbreak with a lower chemical load', art: '4.10', river: 0, haze: 0, soil: 1, ethics: 0, counters: ['WEEDS'], consequence: '+1 soil residue. It creates less modelled pollution than the standard herbicide but can be used only once.', once: true, question: [
    q('Some plant hormones can…', 'Kill weeds without harming crops', ['Add soil nutrients', 'Clear haze', 'Prevent erosion']),
    q('Why is a hormone weedkiller described as selective?', 'It kills weeds while leaving the crop growing', ['It kills every plant it touches', 'It only works at night', 'It adds nutrients to the soil']),
  ] },
  { id: 'HORMONE_RIPEN', name: 'Hormone ripening', gain: '+4 crops to the farm this season', art: '4.11', river: 0, haze: 0, soil: 0, ethics: 0, consequence: 'Fruit ripens together for a one-season harvest boost, but it creates no lasting improvement and can be used once.', once: true, question: [
    q('Other plant hormones can…', 'Regulate fruit growth and ripening', ['Destroy pests', 'Remove weeds forever', 'Replace sunlight']),
    q('Why might a farmer want fruit to ripen at the same time?', 'The whole crop can be harvested and sold together', ['The fruit grows larger forever', 'It keeps pests away', 'It cleans the river']),
  ] },
  { id: 'DO_NOTHING', name: 'Do nothing / recover', gain: 'No new input; remove 1 soil residue and gain +1 crop per plot next season', art: '4.12', river: 0, haze: 0, soil: 0, ethics: 0, counters: ['CALM'], consequence: 'The current world event is not controlled. In return, residues break down and rested soil adds +1 crop per plot next season.', question: [
    q('Why can a low-input season help a farm recover?', 'It allows some chemical residues to break down', ['It kills every pest', 'It adds fertiliser', 'It makes weeds disappear']),
    q('A healthy plant still needs…', 'Air, light, water and nutrients', ['Only pesticides', 'Only ash', 'Haze and herbicide', 'No resources']),
  ] },
];

export const SABOTAGE_QUESTIONS: Question[] = [
  q('Pesticide enters a river, fish take it in, then people eat the fish. What is the problem?', 'Harmful substances move along the food chain', ['Fish grow too large', 'The river dries up', 'Pesticide becomes fertiliser']),
  q('Why do fish die during an algal bloom?', 'There is too little oxygen in the water', ['Algae eat them', 'Water gets too cold', 'Mud blocks their gills']),
  q('Why do bottom-dwelling water plants die during an algal bloom?', 'Sunlight is blocked, so they cannot photosynthesise', ['Algae eat them', 'Water gets salty', 'Carbon dioxide disappears']),
  q('Why does deforestation cause soil erosion?', 'Bare topsoil is exposed to wind and rain', ['Ash makes soil acidic', 'Roots grow too deep', 'Rain cannot reach soil']),
];

export const NEEDS = [
  { id: 'air', label: 'Air', art: '10.1' }, { id: 'light', label: 'Light', art: '10.2' },
  { id: 'water', label: 'Water', art: '10.3' }, { id: 'nutrients', label: 'Nutrients', art: '10.4' },
  { id: 'ph', label: 'Suitable pH', art: '10.5' }, { id: 'pesticides', label: 'Pesticides', art: '10.6' },
  { id: 'herbicides', label: 'Herbicides', art: '10.7' }, { id: 'haze', label: 'Haze', art: '10.8' },
  { id: 'ash', label: 'Ash', art: '10.9' },
] as const;

export const CORRECT_NEEDS = new Set(['air', 'light', 'water', 'nutrients', 'ph']);

function hash(text: string) { return [...text].reduce((value, char) => ((value * 33) ^ char.charCodeAt(0)) >>> 0, 2166136261); }

export function createThreatSchedule(code: string): ThreatId[] {
  let seed = hash(code || 'FARM');
  const repeats: ThreatId[] = ['POOR_SOIL', 'LOCUSTS', 'WEEDS'];
  const deck: ThreatId[] = ['CALM', 'POOR_SOIL', 'LOCUSTS', 'WEEDS', repeats[seed % repeats.length]];
  for (let index = deck.length - 1; index > 0; index -= 1) {
    seed = (seed * 1664525 + 1013904223) >>> 0;
    const swap = seed % (index + 1);
    [deck[index], deck[swap]] = [deck[swap], deck[index]];
  }
  return deck;
}

export function threatFor(room: Pick<RoomState, 'code' | 'season' | 'threatSchedule'>) {
  const schedule = room.threatSchedule?.length === 5 ? room.threatSchedule : createThreatSchedule(room.code);
  return WORLD_EVENTS[schedule[Math.max(0, room.season - 1)] ?? 'CALM'];
}

export function makeFarm(slot: number, name: string, crest: Crest, token?: string): FarmState {
  return { slot, token, crest, name, setupDone: false, setupCorrect: false, plots: 4, plantBonus: 0,
    livestockYield: 0, hasBioControl: false, usedActions: [], ashSeasonsLeft: 0, ashBonus: 0,
    restBonus: 0, pollinatorDamage: 0, erosionDueSeason: null, erosionAmount: 0, soilContamination: 0, ethicsCost: 0,
    sabotageTokens: 1, forcedNext: false, riverContributed: 0, hazeContributed: 0,
    missedDemandStreak: 0, isDesperate: false, totalCrops: 0, history: [], ready: false };
}

export function makeRoom(code: string, farm: FarmState, pairCount = 4): RoomState {
  return { code, pairCount, phase: 'lobby', season: 0, deadline: null, farms: [farm], submissions: {},
    threatSchedule: createThreatSchedule(code), river: 0, haze: 0, riverCostsRevealed: false, hazeCostsRevealed: false,
    algalUntilSeason: 0, events: [], ledgerSeason: [], revision: 0 };
}

export function actionById(id: ActionId) { return ACTIONS.find((action) => action.id === id)!; }

export function isActionLocked(farm: FarmState, action: ActionDefinition) {
  if (farm.forcedNext && action.id !== 'DO_NOTHING') return 'Haze forces this farm to recover';
  if (action.id === 'EMERGENCY_CLEARING' && !farm.isDesperate) return 'Unlocks after missing demand twice';
  if (action.id === 'INTENSIVE' && farm.livestockYield < 3) return 'Needs improved livestock first';
  if (action.once && farm.usedActions.includes(action.id)) return 'Already used';
  return null;
}

function countersThreat(farm: FarmState, action: ActionId, threat: ThreatId) {
  if (threat === 'LOCUSTS' && farm.hasBioControl) return true;
  return actionById(action).counters?.includes(threat) ?? false;
}

export function projectPlotYield(farm: FarmState, action: ActionId, threat: ThreatId, actionApplied = false): PlotYieldBreakdown {
  const futurePlantBonus = !actionApplied && action === 'IMPROVED_PLANT' && farm.plantBonus === 0 ? 1 : 0;
  const futureAshBonus = !actionApplied && (action === 'SLASH_BURN' || action === 'EMERGENCY_CLEARING') ? 1 : 0;
  const plant = (farm.plantBonus ?? 0) + futurePlantBonus;
  const ash = Math.max(farm.ashSeasonsLeft > 0 ? farm.ashBonus : 0, futureAshBonus);
  const rest = farm.restBonus ?? 0;
  const fertiliser = action === 'FERTILISER' ? 2 : 0;
  const potentialPerPlot = 2 + plant + ash + rest + fertiliser;
  let threatPenalty = 0;
  if (!countersThreat(farm, action, threat)) {
    if (threat === 'POOR_SOIL') threatPenalty = plant > 0 ? 2 : 1;
    if (threat === 'LOCUSTS') threatPenalty = 2;
    if (threat === 'WEEDS') threatPenalty = 1;
  }
  const threatLossPerPlot = Math.min(potentialPerPlot, threatPenalty);
  const afterThreat = potentialPerPlot - threatLossPerPlot;
  const biodiversityLossPerPlot = Math.min(afterThreat, farm.pollinatorDamage ?? 0);
  const afterBiodiversity = afterThreat - biodiversityLossPerPlot;
  const establishmentPenalty = action === 'BIO_CONTROL' ? 1 : 0;
  const establishmentLossPerPlot = Math.min(afterBiodiversity, establishmentPenalty);
  const perPlot = Math.max(0, afterBiodiversity - establishmentLossPerPlot);
  const formula = ['2 base'];
  if (plant) formula.push(`+${plant} improved variety`);
  if (ash) formula.push(`+${ash} ash nutrients`);
  if (rest) formula.push(`+${rest} rested soil`);
  if (fertiliser) formula.push(`+${fertiliser} fertiliser nutrients`);
  if (threatLossPerPlot) formula.push(`−${threatLossPerPlot} ${WORLD_EVENTS[threat].name.toLowerCase()}`);
  if (biodiversityLossPerPlot) formula.push(`−${biodiversityLossPerPlot} pollinator loss`);
  if (establishmentLossPerPlot) formula.push(`−${establishmentLossPerPlot} predator habitat`);
  formula.push(`= ${perPlot} crop${perPlot === 1 ? '' : 's'} per plot`);
  return { perPlot, potentialPerPlot, threatLossPerPlot, biodiversityLossPerPlot, establishmentLossPerPlot, formula };
}

export function resolveSeason(room: RoomState): RoomState {
  const next: RoomState = structuredClone(room);
  next.threatSchedule ??= createThreatSchedule(next.code);
  const season = next.season;
  const threat = threatFor(next);
  next.events = next.events.filter((event) => event.kind === 'erosion');
  next.ledgerSeason = [];
  const actual: Record<string, Submission> = {};
  const attemptedActions: Record<string, ActionId> = {};
  const potentialBeforeAction: Record<string, number> = {};
  for (const farm of next.farms) {
    farm.restBonus ??= 0;
    farm.pollinatorDamage ??= 0;
    const baseline = projectPlotYield(farm, 'DO_NOTHING', threat.id);
    potentialBeforeAction[String(farm.slot)] = farm.plots * baseline.perPlot + farm.livestockYield;
    const submitted = next.submissions[String(farm.slot)] ?? { action: 'DO_NOTHING', gateCorrect: false, sabotageTarget: null, sabotageCorrect: null, emote: null };
    attemptedActions[String(farm.slot)] = submitted.action;
    const forced = farm.forcedNext;
    const locked = isActionLocked(farm, actionById(submitted.action));
    farm.forcedNext = false;
    actual[String(farm.slot)] = forced || locked ? { ...submitted, action: 'DO_NOTHING', sabotageTarget: forced ? null : submitted.sabotageTarget } : submitted;
  }
  const sabotageHits: Record<string, number[]> = {};
  for (const farm of next.farms) {
    const sub = actual[String(farm.slot)];
    if (sub.sabotageTarget !== null && farm.sabotageTokens > 0) {
      farm.sabotageTokens -= 1;
      if (sub.sabotageCorrect) {
        const target = next.farms.find((item) => item.slot === sub.sabotageTarget);
        if (target) (sabotageHits[String(target.slot)] ??= []).push(farm.slot);
      } else sub.action = 'DO_NOTHING';
    }
  }
  const recoveryApplied: Record<string, number> = {};
  for (const farm of next.farms) {
    const sub = actual[String(farm.slot)];
    const action = actionById(sub.action);
    if (action.once && !farm.usedActions.includes(action.id)) farm.usedActions.push(action.id);
    if (sub.action === 'SLASH_BURN' || sub.action === 'EMERGENCY_CLEARING') {
      const newPlots = sub.action === 'EMERGENCY_CLEARING' ? 3 : 2;
      farm.plots += newPlots;
      farm.ashSeasonsLeft = 2;
      farm.ashBonus = 1;
      farm.erosionDueSeason = Math.min(farm.erosionDueSeason ?? season + 2, season + 2);
      farm.erosionAmount += newPlots;
    }
    if (sub.action === 'BIO_CONTROL') farm.hasBioControl = true;
    if (sub.action === 'IMPROVED_PLANT') farm.plantBonus = 1;
    if (sub.action === 'IMPROVED_ANIMAL') farm.livestockYield = Math.max(3, farm.livestockYield);
    if (sub.action === 'INTENSIVE' && farm.livestockYield >= 3) farm.livestockYield = 6;
    if (sub.action === 'DO_NOTHING') {
      const before = farm.soilContamination;
      farm.soilContamination = Math.max(0, farm.soilContamination - GAME_RULES.restSoilRecovery);
      recoveryApplied[String(farm.slot)] = before - farm.soilContamination;
    }
    farm.soilContamination += action.soil;
    farm.ethicsCost += action.ethics;
    const livestockRiver = farm.livestockYield >= 6 ? 2 : farm.livestockYield > 0 ? 1 : 0;
    const riverAdded = action.river + livestockRiver;
    farm.riverContributed += riverAdded;
    farm.hazeContributed += action.haze;
    next.river += riverAdded;
    next.haze += action.haze;
    next.ledgerSeason.push({ slot: farm.slot, river: riverAdded, haze: action.haze });
  }
  const riverCap = 2 * next.pairCount;
  const hazeCap = Math.ceil(1.5 * next.pairCount);
  const algalNow = next.river >= riverCap;
  const hazeNow = next.haze >= hazeCap;
  if (algalNow) {
    next.river = 3;
    next.riverCostsRevealed = true;
    next.algalUntilSeason = season + 1;
    next.events.push({ kind: 'algal' });
  }
  if (hazeNow) {
    next.haze = 2;
    next.hazeCostsRevealed = true;
    next.events.push({ kind: 'haze' });
    next.farms.forEach((farm) => { farm.forcedNext = true; });
  }
  const algalActive = next.algalUntilSeason >= season;
  if (algalActive && !next.events.some((event) => event.kind === 'algal')) next.events.push({ kind: 'algal', ongoing: true });
  for (const farm of next.farms) {
    const sub = actual[String(farm.slot)];
    const action = actionById(sub.action);
    const breakdown = projectPlotYield(farm, sub.action, threat.id, true);
    const plotHarvest = farm.plots * breakdown.perPlot;
    const livestockHarvest = farm.livestockYield;
    const ripeningGain = sub.action === 'HORMONE_RIPEN' ? 4 : 0;
    const potentialHarvest = plotHarvest + livestockHarvest + ripeningGain;
    let harvest = potentialHarvest;
    const threatLoss = farm.plots * breakdown.threatLossPerPlot;
    const biodiversityLoss = farm.plots * breakdown.biodiversityLossPerPlot;
    const establishmentLoss = farm.plots * breakdown.establishmentLossPerPlot;
    const threatReason = threatLoss > 0 ? threat.name.toLowerCase() : null;
    const beforeSharedEvent = harvest;
    if (algalActive && livestockHarvest > 0) harvest = Math.max(0, harvest - livestockHarvest);
    if (algalNow) harvest = Math.max(0, harvest - GAME_RULES.algalCropLoss);
    const sharedEventLoss = beforeSharedEvent - harvest;
    const soilEvent = farm.soilContamination >= GAME_RULES.soilThreshold;
    const beforeSoil = harvest;
    if (soilEvent) {
      harvest = Math.floor(harvest / 2);
      farm.soilContamination = 1;
      next.events.push({ kind: 'soil', slots: [farm.slot] });
    }
    const soilLoss = beforeSoil - harvest;
    const sabotagedBy = sabotageHits[String(farm.slot)] ?? [];
    const sabotageLoss = sabotagedBy.length > 0 ? Math.min(GAME_RULES.sabotageCropLoss, harvest) : 0;
    harvest -= sabotageLoss;
    const met = harvest >= DEMAND[season - 1];
    farm.totalCrops += harvest;
    farm.missedDemandStreak = met ? 0 : farm.missedDemandStreak + 1;
    farm.isDesperate = farm.missedDemandStreak >= 2;
    if (season >= 5 && farm.erosionDueSeason !== null && farm.erosionAmount > 0) {
      farm.plots = Math.max(1, farm.plots - farm.erosionAmount);
      farm.erosionDueSeason = null;
      farm.erosionAmount = 0;
      next.events.push({ kind: 'erosion', slots: [farm.slot] });
    }
    farm.history.push({ season, action: sub.action, attemptedAction: attemptedActions[String(farm.slot)], gateCorrect: sub.gateCorrect,
      harvest, potentialHarvest, actionGain: potentialHarvest - potentialBeforeAction[String(farm.slot)], plotHarvest, livestockHarvest,
      ripeningGain, perPlotYield: breakdown.perPlot, plotFormula: breakdown.formula, threatLoss, threatReason, biodiversityLoss,
      establishmentLoss, soilLoss, sharedEventLoss, recoveryApplied: recoveryApplied[String(farm.slot)] ?? 0, met,
      river: next.ledgerSeason.find((row) => row.slot === farm.slot)?.river ?? 0, haze: action.haze, soilEvent,
      burnedSeasonFive: season === 5 && (sub.action === 'SLASH_BURN' || sub.action === 'EMERGENCY_CLEARING'), emote: sub.emote,
      sabotageTarget: sub.sabotageCorrect ? sub.sabotageTarget : null, sabotageFailed: sub.sabotageCorrect === false, sabotagedBy, sabotageLoss });
    farm.restBonus = sub.action === 'DO_NOTHING' ? 1 : 0;
    farm.pollinatorDamage = sub.action === 'PESTICIDE' ? 1 : 0;
    if (farm.ashSeasonsLeft > 0) farm.ashSeasonsLeft -= 1;
    if (farm.ashSeasonsLeft === 0) farm.ashBonus = 0;
    farm.ready = false;
  }
  next.submissions = {};
  next.deadline = null;
  next.phase = season >= 5 ? 'final' : 'results';
  next.revision += 1;
  return next;
}

export function startNextSeason(room: RoomState, now = Date.now()): RoomState {
  const next: RoomState = structuredClone(room);
  next.threatSchedule ??= createThreatSchedule(next.code);
  next.season += 1;
  next.phase = 'choice';
  next.deadline = now + CHOICE_TIME_MS;
  next.events = [];
  for (const farm of next.farms) {
    farm.restBonus ??= 0;
    farm.pollinatorDamage ??= 0;
    if (farm.erosionDueSeason === next.season) {
      farm.plots = Math.max(1, farm.plots - farm.erosionAmount);
      farm.erosionDueSeason = null;
      farm.erosionAmount = 0;
      next.events.push({ kind: 'erosion', slots: [farm.slot] });
    }
    farm.ready = false;
  }
  next.revision += 1;
  return next;
}

export function missedDemandCount(farm: FarmState) {
  return farm.history.filter((item) => !item.met).length;
}

export function finalScore(farm: FarmState) {
  return farm.totalCrops - SCORE_MULTIPLIERS.river * farm.riverContributed - SCORE_MULTIPLIERS.haze * farm.hazeContributed - SCORE_MULTIPLIERS.soil * farm.soilContamination - SCORE_MULTIPLIERS.ethics * farm.ethicsCost - GAME_RULES.missedDemandPenalty * missedDemandCount(farm);
}

export function rankFarms(farms: FarmState[]) {
  return [...farms].sort((a, b) => finalScore(b) - finalScore(a) || b.totalCrops - a.totalCrops || a.slot - b.slot);
}

function shuffledQuestion(question: Question, seed: number): Question {
  const options = [...question.options];
  for (let index = options.length - 1; index > 0; index -= 1) {
    const swap = (seed + index * 17) % (index + 1);
    [options[index], options[swap]] = [options[swap], options[index]];
  }
  return { ...question, options };
}

export function seededQuestion(action: ActionDefinition, roomCode: string, slot: number, season: number) {
  const seed = [...`${roomCode}${slot}${season}${action.id}`].reduce((value, char) => ((value * 31) + char.charCodeAt(0)) >>> 0, 7);
  return shuffledQuestion(action.question[seed % action.question.length], seed);
}

export function seededSabotageQuestion(roomCode: string, slot: number, season: number) {
  const seed = [...`${roomCode}${slot}${season}SABOTAGE`].reduce((value, char) => ((value * 31) + char.charCodeAt(0)) >>> 0, 11);
  return shuffledQuestion(SABOTAGE_QUESTIONS[seed % SABOTAGE_QUESTIONS.length], seed);
}

export function scienceStars(farm: FarmState) {
  return farm.history.filter((item) => item.gateCorrect).length;
}
