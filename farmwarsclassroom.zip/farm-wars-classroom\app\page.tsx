import FarmWarsGame from './game/FarmWarsGame';

export default function Home() { return <FarmWarsGame />; }
